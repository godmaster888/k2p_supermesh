#define MY_VER_MAJOR 4
#define MY_VER_MINOR 57
#define MY_VER_BUILD 0
#define MY_VERSION "4.57"
#define MY_7ZIP_VERSION "7-Zip 4.57"
#define MY_DATE "2007-12-06"
#define MY_COPYRIGHT "Copyright (c) 1999-2007 Igor Pavlov"
#define MY_VERSION_COPYRIGHT_DATE MY_VERSION "  " MY_COPYRIGHT "  " MY_DATE
