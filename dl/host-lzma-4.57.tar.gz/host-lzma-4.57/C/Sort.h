/* Sort.h */

#ifndef __7Z_Sort_H
#define __7Z_Sort_H

#include "Types.h"

void HeapSort(UInt32 *p, UInt32 size);
/* void HeapSortRef(UInt32 *p, UInt32 *vals, UInt32 size); */

#endif
