#ifndef _IP6TABLES_MULTI_H
#define _IP6TABLES_MULTI_H 1

extern int ip6tables_main(int, char **);
extern int ip6tables_save_main(int, char **);
extern int ip6tables_restore_main(int, char **);

#endif /* _IP6TABLES_MULTI_H */
