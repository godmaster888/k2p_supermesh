/*
 * Copyright (c) 2017 Denys Vlasenko <vda.linux@googlemail.com>
 *
 * Licensed under GPLv2, see file LICENSE in this source tree.
 */
//config:config MINIPS
//config:	bool "minips (11 kb)"
//config:	default n  # for god's sake, just use "ps" name in your scripts
//config:	help
//config:	Alias to "ps".

/* applet and kbuild hooks are in ps.c */
