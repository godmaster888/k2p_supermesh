The header files in this directory and below were taken from:

    https://github.com/guidovranken/fuzzing-headers.git

Some minor modifications were made to make them build with the default C++
warning flags.
