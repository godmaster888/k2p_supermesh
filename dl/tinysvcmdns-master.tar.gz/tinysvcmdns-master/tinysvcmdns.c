#include <unistd.h>

#ifdef SUPPORT_IPV6
#include <arpa/inet.h>
#endif /* SUPPORT_IPV6 */

#ifdef DLINK_SOFTWARE
#include <d-link/d_service_notify.h>
#endif /* DLINK_SOFTWARE */

#include "mdns.h"
#include "mdnsd.h"

int main(int argc, char *argv[]) {
	struct mdnsd *s;

#ifdef DLINK_SOFTWARE
	if (argc < 6)
		return -1;

	setenv("DLINK_FWMARK", argv[5], 0);
#else
	if (argc != 5)
		return -1;
#endif

	s = mdnsd_start(argv[3], argv[2]);
	if (!s)
		return -1;

#ifdef DLINK_SOFTWARE
	dlink_service_connect(0); // D-Link: connect to daemon
#endif /* DLINK_SOFTWARE */

	mdnsd_set_hostname(s, argv[1], inet_addr(argv[2]));

#ifdef SUPPORT_IPV6
	struct in6_addr addr6;

	if (inet_pton(AF_INET6, argv[4], &addr6) == 1) {
		struct rr_entry *aaaa, *nsec;

		aaaa = rr_create_aaaa(create_nlabel(argv[1]), &addr6);
		mdnsd_add_rr(s, aaaa);

		nsec = rr_create(create_nlabel(argv[1]), RR_NSEC);
		rr_set_nsec(nsec, RR_AAAA);
		mdnsd_add_rr(s, nsec);
	}
#endif /* SUPPORT_IPV6 */

	pause();

	mdnsd_stop(s);

	return 0;
}
