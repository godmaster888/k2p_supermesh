#ifdef DLINK_SOFTWARE
#ifdef SUPPORT_SAFEDNS

#include "dnsmasq.h"
#include <ctype.h>
#include <jansson.h>

#define SAFEDNS_CONFIG_FILE	"/tmp/safedns_config"

int safedns_enable = 0;
static unsigned int safedns_default_token = 0;
static unsigned short safedns_port = 0;
static json_t *safedns_device = NULL;

void safedns_load_config(void) {
	json_t *config_obj;

	config_obj = json_load_file(SAFEDNS_CONFIG_FILE, 0, NULL);
	if (!json_is_object(config_obj))
		goto cleanup;

	safedns_enable = json_boolean_value(json_object_get(config_obj, "enable"));
	if (!safedns_enable)
		goto cleanup;

	safedns_default_token = (unsigned int)json_integer_value(json_object_get(config_obj, "default_token"));
	if (!safedns_default_token) {
		safedns_enable = 0;
		goto cleanup;
	}

	safedns_port = (unsigned short)json_integer_value(json_object_get(config_obj, "port"));
	if (!safedns_port) {
		safedns_enable = 0;
		goto cleanup;
	}

	safedns_device = json_deep_copy(json_object_get(config_obj, "device"));

cleanup:
	json_decref(config_obj);
}

static unsigned int safedns_get_token(union mysockaddr *ap, time_t now) {
	int maclen, i;
	char mac[6], pretty_mac[18];
	unsigned int token;

	maclen = find_mac(ap, mac, 0, now);
	if (maclen != 6)
		return safedns_default_token;

	print_mac(pretty_mac, mac, maclen);

	for (i = 0; i < strlen(pretty_mac); i++)
		pretty_mac[i] = toupper(pretty_mac[i]);

	token = (unsigned int)json_integer_value(json_object_get(safedns_device, pretty_mac));
	if (!token)
		token = safedns_default_token;

	return token;
}

size_t safedns_fix_packet_port(unsigned char *hp, size_t plen, unsigned short *pp,
                               unsigned char *ap, time_t now) {
	struct dns_header *header = (struct dns_header *)hp;
	union mysockaddr *addr = (union mysockaddr *)ap;
	unsigned char *arp;

	arp = skip_questions(header, plen);
	if (!arp)
		goto fix_port;

	if (add_resource_record(header, NULL, NULL, 0, &arp, 0UL, NULL, T_SAFEDNS,
	                        C_IN, "l", NULL, safedns_get_token(addr, now))) {
		header->arcount = htons(1U);
		plen = arp - hp;
	}

fix_port:
	if (pp)
		*pp = htons(safedns_port);

	return plen;
}

#endif /* SUPPORT_SAFEDNS */
#endif /* DLINK_SOFTWARE */
