#ifdef DLINK_SOFTWARE
#ifdef SUPPORT_SAFEDNS

#ifndef __SAFEDHS_H__
#define __SAFEDHS_H__

#include <stddef.h>
#include <time.h>

extern int safedns_enable;
extern int safedns_default_token;

void safedns_load_config(void);
size_t safedns_fix_packet_port(unsigned char *header, size_t plen, unsigned short *pp,
                               unsigned char *ap, time_t now);

#endif /* __SAFEDNS_H__ */

#endif /* SUPPORT_SAFEDNS */
#endif /* DLINK_SOFTWARE */
