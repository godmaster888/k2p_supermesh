#ifndef DLINK_H
#define DLINK_H

#ifndef COPYRIGHT
#include "dnsmasq.h"
#endif

static inline unsigned int search_fwmark(unsigned int if_index)
{
	struct iname *if_tmp;
	unsigned int index = 0;

	for (if_tmp = daemon->if_names; if_tmp; if_tmp = if_tmp->next) {
		if (!if_tmp->name)
			continue;
		index = if_nametoindex(if_tmp->name);

		if (index != if_index)
			continue;

		return if_tmp->fwmark;
	}

	return 0;
}


#endif
