#ifndef INTERNAL_H
#define INTERNAL_H 1

#include "config.h"
#ifdef HAVE_VISIBILITY_HIDDEN
#	define __visible	__attribute__((visibility("default")))
#	define EXPORT_SYMBOL(x)	typeof(x) (x) __visible
#else
#	define EXPORT_SYMBOL(x)
#endif

#ifndef NLA_F_NESTED
 #define NLA_F_NESTED            (1 << 15)
#endif

#ifndef NLA_F_NET_BYTEORDER
 #define NLA_F_NET_BYTEORDER     (1 << 14)
#endif

#ifndef NLA_TYPE_MASK
 #define NLA_TYPE_MASK	~(NLA_F_NESTED | NLA_F_NET_BYTEORDER)
#endif

#endif
