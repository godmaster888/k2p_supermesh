/*
 * (C) 2008-2012 by Pablo Neira Ayuso <pablo@netfilter.org>
 * (C) 2016 by Konstantin Vasin <kvasin@dlink.ru>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 */

#include <stdlib.h>
#include <time.h>

#include <libmnl/libmnl.h>
#include <linux/genetlink.h>

#include "internal.h"

static int data_attr_cb(const struct nlattr *attr, void *data)
{
	const struct nlattr **tb = data;
	int type = mnl_attr_get_type(attr);

	if (mnl_attr_type_valid(attr, CTRL_ATTR_MAX) < 0)
		return MNL_CB_OK;

	if (type == CTRL_ATTR_FAMILY_ID)
		if (mnl_attr_validate(attr, MNL_TYPE_U16) < 0)
			return MNL_CB_ERROR;

	tb[type] = attr;
	return MNL_CB_OK;
}

static int get_family_id_cb(const struct nlmsghdr *nlh, void *data)
{
	struct nlattr *tb[CTRL_ATTR_MAX+1] = {};
	struct genlmsghdr *genl = mnl_nlmsg_get_payload(nlh);

	mnl_attr_parse(nlh, sizeof(*genl), data_attr_cb, tb);
	if (tb[CTRL_ATTR_FAMILY_ID]) {
		*(unsigned int *)data = mnl_attr_get_u16(tb[CTRL_ATTR_FAMILY_ID]);
	}
	return MNL_CB_OK;
}

/**
 * mnl_genl_get_family_id - get Generic Netlink family id by name.
 * \param family_name name of the Generic Netlink family.
 *
 * This function returns family id on success, 0 otherwise.
 */
unsigned int
mnl_genl_get_family_id(const char *family_name)
{
	struct mnl_socket *nl;
	char buf[MNL_SOCKET_BUFFER_SIZE];
	struct nlmsghdr *nlh;
	struct genlmsghdr *genl;
	int ret;
	unsigned seq, portid;
	unsigned int family_id = 0;

	memset(buf, 0, sizeof(buf));

	if (!family_name || !*family_name)
		return 0;

	nlh = mnl_nlmsg_put_header(buf);
	nlh->nlmsg_type = GENL_ID_CTRL;
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;
	nlh->nlmsg_seq = seq = time(NULL);

	genl = mnl_nlmsg_put_extra_header(nlh, sizeof(struct genlmsghdr));
	genl->cmd = CTRL_CMD_GETFAMILY;
	genl->version = 1;

	mnl_attr_put_u32(nlh, CTRL_ATTR_FAMILY_ID, GENL_ID_CTRL);
	mnl_attr_put_strz(nlh, CTRL_ATTR_FAMILY_NAME, family_name);

	nl = mnl_socket_open(NETLINK_GENERIC);
	if (nl == NULL)
		return 0;

	if (mnl_socket_bind(nl, 0, MNL_SOCKET_AUTOPID) < 0)
		goto err_exit;

	portid = mnl_socket_get_portid(nl);

	if (mnl_socket_sendto(nl, nlh, nlh->nlmsg_len) < 0)
		goto err_exit;

	ret = mnl_socket_recvfrom(nl, buf, sizeof(buf));
	while(ret > 0) {
		ret = mnl_cb_run(buf, ret, seq, portid, get_family_id_cb, &family_id);
		if (ret <= 0)
			break;
		ret = mnl_socket_recvfrom(nl, buf, sizeof(buf));
	}
err_exit:
	mnl_socket_close(nl);
	return family_id;
}
EXPORT_SYMBOL(mnl_genl_get_family_id);

