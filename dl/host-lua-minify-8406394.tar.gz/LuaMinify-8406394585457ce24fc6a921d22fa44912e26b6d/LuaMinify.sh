#!/bin/sh

lua "$(dirname $(realpath "$0"))/CommandLineMinify.lua" $@
