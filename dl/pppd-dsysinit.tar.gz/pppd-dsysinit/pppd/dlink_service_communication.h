#include <jansson.h>
#include "pppd.h"
#include <d-link/d_service_notify.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define INET_ADDRSTRLEN_PFX (INET_ADDRSTRLEN + 3)
#define INET6_ADDRSTRLEN_PFX (INET6_ADDRSTRLEN + 4)

typedef enum {
	PHASE_CHANGED,
	AUTH,
	IPCP,
	STATUS
} PPP_event_t;

static const char *_PPP_EVENTS[] =
{
	"PhaseChanged",
	"Auth",
	"IPCP",
	"Status"
};

static inline void pass_event(PPP_event_t event, json_t *data) {
	char *data_str = NULL;
	json_t *msg = json_object();

	/* Setting event type */
	json_object_set_new_nocheck(msg, "EventType", json_string(_PPP_EVENTS[event]));
	json_object_set_nocheck(msg, "EventInfo", data);  // incref data

	FILE *fp = fopen(xl2tp_control_file, "w");

	if (fp) {
		data_str = json_dumps(msg, JSON_COMPACT | JSON_ENCODE_ANY);
		fprintf(fp, "p %s", data_str);
		fclose(fp);
	}

	json_decref(msg);
	free(data_str);
}

static inline void send_event(PPP_event_t event, json_t *data, const char *hash) {
	json_t *msg = json_object();

	/* Setting event type */
	json_object_set_new_nocheck(msg, "EventType", json_string(_PPP_EVENTS[event]));
	json_object_set_nocheck(msg, "EventInfo", data);  // incref data

	if (hash)
		dlink_service_update_by_hash(msg, hash);
	else
		dlink_service_update(msg);

	// do not json_decref(msg), because it is already done by dlink_service_update(msg)
}

static inline json_t *init_msg_data(void) {
	json_t *data = json_object();

	return data;
}

static inline void data_append_phase_number(json_t *data, int phase) {
	json_object_set_new_nocheck(data, "PhaseNumber", json_integer(phase));
}

static inline char *convert_ip(u_int32_t ip, bool pref, char *buf, size_t sizebuf) {
	struct in_addr addr;

	addr.s_addr = ip;
	snprintf(buf, sizebuf, "%s%s", inet_ntoa(addr), pref ? "/32" : "");

	return buf;
}

static inline char *convert_ipv6(const char *ipv6, bool pref, char *buf, size_t size)
{
	if (size < INET6_ADDRSTRLEN_PFX || !ipv6) {
		snprintf(buf, sizeof(buf), "");
		return buf;
	}

	strcpy(buf, ipv6);

	if (pref && !strrchr(ipv6, '/'))
		strcat(buf, "/64");

	return buf;
}

static inline void data_append_local_ipv6(json_t *data, const char *ipv6)
{
	char buf[INET6_ADDRSTRLEN_PFX];
	convert_ipv6(ipv6, 1, buf, sizeof(buf));

	json_object_set_new_nocheck(data, "LocalIP", json_string(buf));
}

static inline void data_append_remote_ipv6(json_t *data, const char *ipv6)
{
	char buf[INET6_ADDRSTRLEN_PFX];
	convert_ipv6(ipv6, 1, buf, sizeof(buf));

	json_object_set_new_nocheck(data, "RemoteIP", json_string(buf));
}

static inline void data_append_local_ip(json_t *data, u_int32_t ip) {
	if (!ip)
		return;

	char str[INET_ADDRSTRLEN_PFX];
	convert_ip(ip, 1, str, sizeof(str));
	json_object_set_new_nocheck(data, "LocalIP", json_string(str));
}

static inline void data_append_remote_ip(json_t *data, u_int32_t ip) {
	if (!ip)
		return;

	char str[INET_ADDRSTRLEN_PFX];
	convert_ip(ip, 1, str, sizeof(str));
	json_object_set_new_nocheck(data, "RemoteIP", json_string(str));
}

static inline void append_addr_to_array(json_t *array, u_int32_t raw_dns) {
	if (!raw_dns)
		return;

	char str[INET_ADDRSTRLEN_PFX];
	convert_ip(raw_dns, 0, str, sizeof(str));
	json_array_append_new(array, json_string(str));
}

static inline void data_append_dns_ip(json_t *data, u_int32_t dns_prim, u_int32_t dns_snd) {
	json_t *dns_storage = json_array();

	append_addr_to_array(dns_storage, dns_prim);
	append_addr_to_array(dns_storage, dns_snd);

	json_object_set_new_nocheck(data, "DNS", dns_storage);
}

static inline void data_append_iface_name(json_t *data, const char *name) {
	json_object_set_new_nocheck(data, "IfaceName", json_string(name));
}

static inline void data_append_session_id(json_t *data, int session_id) {
	json_object_set_new_nocheck(data, "SessionId", json_integer(session_id));
}

static inline void data_append_remote_number(json_t *data, const char *rem_num) {
	json_object_set_new_nocheck(data, "RemoteNumber", json_string(rem_num));
}

static inline void data_append_unit(json_t *data, int status) {
	json_object_set_new_nocheck(data, "Unit", json_integer(status));
}

static inline void data_append_code_status(json_t *data, int status) {
	json_object_set_new_nocheck(data, "CodeStatus", json_integer(status));
}

static inline void data_append_linkname(json_t *data, const char *linkname) {
	json_object_set_new_nocheck(data, "LinkName", json_string(linkname));
}

static inline void data_append_already(json_t *data, int already) {
	json_object_set_new_nocheck(data, "Already", json_integer(already));
}
