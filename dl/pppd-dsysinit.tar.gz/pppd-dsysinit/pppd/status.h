
#ifndef   __STATUS_H__INCLUDED__
#define   __STATUS_H__INCLUDED__

void  do_exit( int  status );

void  do_start();

void  stat_link( int a_bStat );

void  stat_auth( int  a_bStat );

void  stat_server( int  a_bStat );

#endif
