
#include <stdio.h>
#include <stdlib.h>
#include <syslog.h>

#include <sys/stat.h>

//-----------------------------------------------------------------------------

char  *z_ppp_status = "/var/log/pppstatus";  // status string
char  *z_ppp_result = "/var/log/pppresult";  // result number
char  *z_ppp_chain  = "/var/log/pppchain";   // status chain

enum
{
  kePPPIdle          = 0,
  kePPPSuccess       = 1,
  kePPPStart         = 2,
  kePPPServer        = 3,
  kePPPProto         = 4,
  kePPPAuth          = 5,
};

char *az_ppp_result[] = 
{
  "Disconnected",
  "Connected",
  "Connection",
  "No responce",
  "Protocol error",
  "Auth error",
  NULL
};

//-----------------------------------------------------------------------------

void
_stat_write_status( int a_nStat )
{
  FILE  *fp;

  fp = fopen( z_ppp_status, "w" );
  if( NULL != fp )
  {
    fprintf( fp, "%s\n", az_ppp_result[ a_nStat ] );
    fclose( fp );
  }
}

void
_stat_write_result( int a_nStat )
{
  FILE  *fp;

  fp = fopen( z_ppp_result, "w" );
  if( NULL != fp )
  {
    fprintf( fp, "%d\n", a_nStat );
    fclose( fp );
  }
}

void
_stat_write_chain( int a_nStat )
{
  FILE           *fp;
  struct  stat   tStat;

  if( -1 != stat( z_ppp_chain, &tStat ) )
  {
    if( tStat.st_size > 64 )
      unlink( z_ppp_chain );
  }

  fp = fopen( z_ppp_chain, "a+" );
  if( NULL != fp )
  {
    fprintf( fp, "%d\n", a_nStat );
    fclose( fp );
  }
}

int
_stat_get()
{
  FILE           *fp;
  int             nStat;

  fp = fopen( z_ppp_result, "r" );
  if( NULL != fp )
  {
    if( 1 != fscanf( fp, "%d", &nStat ) )
      nStat = kePPPIdle;
    fclose( fp );

    return nStat;
  }
  return kePPPIdle;
}

//-----------------------------------------------------------------------------

void
do_exit( int status )
{
  int   ppp_status;

  if( 0 != status )
  {
    ppp_status = _stat_get();
    if( kePPPStart == ppp_status )
    {
      _stat_write_status( kePPPProto );
      _stat_write_result( kePPPProto );
      _stat_write_chain( kePPPProto );
    }
  }

  exit( status );
}

void
do_start()
{
  _stat_write_result( kePPPStart );
  _stat_write_status( kePPPStart );
  _stat_write_chain( kePPPStart );
}

void
stat_link( int a_bStat )
{
  int    status;

  if( a_bStat )
    status = kePPPSuccess;
  else
    status = kePPPIdle;

  _stat_write_result( status );
  _stat_write_status( status );
  _stat_write_chain( status );
}

void
stat_auth( int  a_bStat )
{
  int   status;

  status = _stat_get();

  if( 0 == a_bStat )
  {
    if( kePPPStart == status )
    {
      _stat_write_result( kePPPAuth );
      _stat_write_status( kePPPAuth );
    }
    _stat_write_chain( kePPPAuth );
  }
}

void
stat_server( int  a_bStat )
{
  int   status;

  status = _stat_get();

  if( 0 == a_bStat )
  {
    _stat_write_result( kePPPServer );
    _stat_write_status( kePPPServer );

    _stat_write_chain( kePPPServer );
  }
}

