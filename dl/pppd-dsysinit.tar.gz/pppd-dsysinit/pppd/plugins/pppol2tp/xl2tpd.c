/*
 * Layer Two Tunnelling Protocol Daemon
 * Copyright (C) 1998 Adtran, Inc.
 * Copyright (C) 2002 Jeff McAdams
 *
 *
 * Mark Spencer
 *
 * This software is distributed under the terms
 * of the GPL, which you should have received
 * along with this source.
 *
 * Main Daemon source.
 *
 */

#define _ISOC99_SOURCE
#define _XOPEN_SOURCE
#define _BSD_SOURCE
#define _XOPEN_SOURCE_EXTENDED

#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#if (__GLIBC__ < 2)
# if defined(FREEBSD)
#  include <sys/signal.h>
# elif defined(LINUX)
#  include <bsd/signal.h>
# elif defined(SOLARIS)
#  include <signal.h>
# endif
#else
# include <signal.h>
#endif
#include <netdb.h>
#include <string.h>
#include <strings.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/route.h>
#include <sys/ioctl.h>
#include "l2tp.h"
#include <sys/ipc.h>
#include <sys/shm.h>

#define CONFIG_SEM_KEY_FILE "/VERSION"

struct tunnel_list tunnels;
int max_tunnels = DEF_MAX_TUNNELS;
int rand_source;
int ppd = 1;                    /* Packet processing delay */

int iexit = 0;
int isock_fd = -1;
pid_t control_pid = -1, manager_pid = -1;
key_t key;

typedef struct {
	int ifd;
	uint32_t ipv4_addr;
	uint16_t port;
	uint32_t ourtid;
	uint32_t ourcid;
	uint32_t tid;
	uint32_t cid;
} SHT, *PSHT;

int shmid;
PSHT segptr = NULL;

extern int _stat_get();
extern void _stat_write_status( int a_nStat );
extern void _stat_write_result( int a_nStat );
extern void _stat_write_chain( int a_nStat );

/* dlink */
#define CMD_SIZE 2048
#define MAX_COMMAND_SIZE 999

int sent_ppp_down(char* iface) {

	char bufecho[CMD_SIZE];
	char buffer[MAX_COMMAND_SIZE];
	buffer[0]='\0';

	snprintf(buffer, sizeof(buffer), "action:down;iface:%s", iface);
	snprintf(bufecho,sizeof(bufecho),"echo \"P%03u%s\"> /tmp/resident.events", strlen(buffer),buffer);
	system(bufecho);
	return 0;
}


void init_tunnel_list (struct tunnel_list *t) {
	t->head = NULL;
	t->count = 0;
	t->calls = 0;
}

void stop_pppd (int istat) {
	if( istat != -1 ) {
		_stat_write_status(istat);
		_stat_write_result(istat);
		_stat_write_chain(istat);
		l2tp_log (LOG_WARNING, "%s: exit(%d).\n", __FUNCTION__, istat);
	}

	if( !iexit ) {
		iexit = 1;
		if( istat != -1 && control_pid != -1 ) {
			l2tp_log (LOG_DEBUG, "%s: hup parent pid %d\n", __FUNCTION__, control_pid);
			kill(control_pid, SIGHUP);
		}
		segptr->ifd = -2; /* notify mark */
	}

	if (istat == 3) {
		l2tp_log (LOG_DEBUG, "Use iface %s.\n", ppp_ifname);
		sent_ppp_down(ppp_ifname);
	}
}

void start_pppd (struct call *c) {
	segptr->ifd = server_socket;
	segptr->ipv4_addr = c->container->peer.sin_addr.s_addr;
	segptr->port = c->container->peer.sin_port;
	segptr->ourtid = c->container->ourtid;
	segptr->ourcid = c->ourcid;
	segptr->tid = c->container->tid;
	segptr->cid = c->cid;
}

void destroy_tunnel (struct tunnel *t) {
    /*
     * Immediately destroy a tunnel (and all its calls)
     * and free its resources.  This may be called
     * by the tunnel itself,so it needs to be
     * "suicide safe"
     */
     
    struct call *c, *me;
    struct tunnel *p;
    struct timeval tv;
    if (!t)
        return;

    /*
     * Save ourselves until the very
     * end, since we might be calling this ourselves.
     * We must divorce ourself from the tunnel
     * structure, however, to avoid recursion
     * because of the logic of the destroy_call
     */
    me = t->self;

    /*
     * Destroy all the member calls
     */
    c = t->call_head;
    while (c)
    {
        destroy_call (c);
        c = c->next;
    };
    /*
     * Remove ourselves from the list of tunnels
     */

    if (tunnels.head == t)
    {
        tunnels.head = t->next;
        tunnels.count--;
    }
    else
    {
        p = tunnels.head;
        if (p)
        {
            while (p->next && (p->next != t))
                p = p->next;
            if (p->next)
            {
                p->next = t->next;
                tunnels.count--;
            }
            else
            {
                l2tp_log (LOG_WARNING,
                     "%s: unable to locate tunnel in tunnel list\n",
                     __FUNCTION__);
            }
        }
        else
        {
            l2tp_log (LOG_WARNING, "%s: tunnel list is empty!\n", __FUNCTION__);
        }
    }
    if (t->lac) {
        t->lac->t = NULL;
    }
    /* XXX L2TP/IPSec: remove relevant SAs here?  NTB 20011010
     * XXX But what if another tunnel is using same SA?
     */
    if (t->chal_us.challenge)
        free (t->chal_us.challenge);
    if (t->chal_them.challenge)
        free (t->chal_them.challenge);
    /* we need no free(t->chal_us.vector) here because we zalloc() and free()
       the memory pointed to by t->chal_us.vector at some other place */
    if (t->chal_them.vector)
        free (t->chal_them.vector);
    free (t);
    free (me);
}

struct tunnel *l2tp_call (char *host, int port, struct lac *lac)
{
    /*
     * Establish a tunnel from us to host
     * on port port
     */
    struct call *tmp = NULL;
    unsigned int addr;

	char *buf;
	size_t buflen = 512;
    struct hostent *hp;
	struct hostent hbuf;
	int rc;
	int herr;

    port = htons (port);

	buf = malloc(buflen);
	if (!buf)
		goto lookup_fail;

	while((rc = gethostbyname2_r(host, AF_INET, &hbuf, buf, buflen, &hp, &herr)) == ERANGE) {

		l2tp_log(LOG_WARNING, "Need more memory!\n");
		buflen *= 2;

		char *tmpbuff = realloc(buf, buflen);
		if (!tmpbuff) {
			free(buf);
			l2tp_log(LOG_WARNING, "Out of memory!\n");
			goto lookup_fail;
		}

		buf = tmpbuff;
	}

	if (rc == 0 && hp)
		goto lookup_ok;

lookup_fail:
	l2tp_log (LOG_WARNING, "Host name lookup failed for %s.\n", host);
	// zw : if server doesn't lookup -- exit
	stop_pppd(3);
	return NULL;

lookup_ok:

//	l2tp_log (LOG_WARNING, "h_addr=%s h_length=%d\n", hp->h_addr,hp->h_length);
	//bcopy (hp->h_addr, &addr, hp->h_length);
	memcpy(&addr, hp->h_addr_list[0], sizeof(struct in_addr));
	free(buf);

    /* Force creation of a new tunnel
       and set it's tid to 0 to cause
       negotiation to occur */
    /*
     * to do IPsec properly here, we need to set a socket policy,
     * and/or communicate with pluto.
     */

    tmp = get_call (0, 0, addr, port, IPSEC_SAREF_NULL, IPSEC_SAREF_NULL);
    if (!tmp)
    {
        l2tp_log (LOG_WARNING, "%s: Unable to create tunnel to %s.\n", __FUNCTION__,
             host);
        return NULL;
    }
    tmp->container->tid = 0;
    tmp->container->lac = lac;
    tmp->lac = lac;
    if (lac)
        lac->t = tmp->container;
    /*
     * Since our state is 0, we will establish a tunnel now
     */
    l2tp_log (LOG_NOTICE, "Connecting to host %s, port %d\n", host,
         ntohs (port));
    control_finish (tmp->container, tmp);
    return tmp->container;
}

void magic_lac_tunnel (void *data)
{
    struct lac *lac;

    lac = (struct lac *) data;
    if (!lac)
    {
        l2tp_log (LOG_WARNING, "%s: magic_lac_tunnel: called on NULL lac!\n",
             __FUNCTION__);
        return;
    }

    if (lac->lns)
    {

        /* FIXME: I should try different LNS's if I get failures */
        l2tp_call (lac->lns->hostname, lac->lns->port, lac);
        return;
    }
    else
    {

        l2tp_log (LOG_WARNING, "%s: Unable to find hostname to dial for '%s'\n",
             __FUNCTION__, lac->entname);
        return;
    }
}

struct call *lac_call (int tid, struct lac *lac)
{
    struct tunnel *t = tunnels.head;
    struct call *tmp;
    
    while (t)
    {
        if (t->ourtid == tid)
        {
            tmp = new_call (t);
            if (!tmp)
            {
                l2tp_log (LOG_WARNING, "%s: unable to create new call\n",
                     __FUNCTION__);
                return NULL;
            }
            tmp->next = t->call_head;
            t->call_head = tmp;
            t->count++;
            tmp->cid = 0;
            tmp->lac = lac;
            if (lac)
                lac->c = tmp;
            l2tp_log (LOG_NOTICE, "Calling on tunnel %d\n", tid);
            control_finish (t, tmp);
            return tmp;
        }
        t = t->next;
    };
    l2tp_log (LOG_DEBUG, "%s: No such tunnel %d to generate call.\n", __FUNCTION__,
         tid);
    return NULL;
}

void magic_lac_dial (void *data)
{
    struct lac *lac;
    lac = (struct lac *) data;
    
    if (!lac->active)
    {
        l2tp_log (LOG_DEBUG, "%s: LAC %s not active", __FUNCTION__, lac->entname);
        return;
    }
    
    lac->rsched = NULL;
    if (!lac)
    {
        l2tp_log (LOG_WARNING, "%s : called on NULL lac!\n", __FUNCTION__);
        return;
    }
    
    if (!lac->t)
    {
#ifdef DEGUG_MAGIC
        l2tp_log (LOG_DEBUG, "%s : tunnel not up!  Connecting!\n", __FUNCTION__);
#endif

        magic_lac_tunnel (lac);
        return;
    }
    
    lac_call (lac->t->ourtid, lac);
    
}

void lac_hangup (int cid)
{
    struct tunnel *t = tunnels.head;
    struct call *tmp;
    while (t)
    {
        tmp = t->call_head;
        while (tmp)
        {
            if (tmp->ourcid == cid)
            {
                l2tp_log (LOG_INFO,
                     "%s :Hanging up call %d, Local: %d, Remote: %d\n",
                     __FUNCTION__, tmp->serno, tmp->ourcid, tmp->cid);
                strcpy (tmp->errormsg, "Goodbye!");
		stop_pppd(0);
                return;
            }
            tmp = tmp->next;
        }
        t = t->next;
    };
    l2tp_log (LOG_DEBUG, "%s : No such call %d to hang up.\n", __FUNCTION__, cid);
    return;
}

void lac_disconnect (int tid)
{
    struct tunnel *t = tunnels.head;
    while (t)
    {
        if (t->ourtid == tid )
        {
            l2tp_log (LOG_INFO,
                 "Disconnecting from %s, Local: %d, Remote: %d\n",
                 IPADDY (t->peer.sin_addr), t->ourtid, t->tid);
            t->self->needclose = -1;
            strcpy (t->self->errormsg, "Goodbye!");
            call_close (t->self);
            return;
        }
        t = t->next;
    };
    //l2tp_log (LOG_DEBUG, "No such tunnel %d to hang up.\n", tid);
    return;
}


struct tunnel *new_tunnel ()
{
    struct tunnel *tmp = zalloc (sizeof (struct tunnel));
    unsigned char entropy_buf[2] = "\0";
    if (!tmp)
        return NULL;
    tmp->control_seq_num = 0;
    tmp->control_rec_seq_num = 0;
    tmp->cLr = 0;
    tmp->call_head = NULL;
    tmp->next = NULL;
    tmp->debug = -1;
    tmp->tid = -1;
    tmp->hello = NULL;
#ifndef TESTING
/*      while(get_call((tmp->ourtid = rand() & 0xFFFF),0,0,0)); */
/*        tmp->ourtid = rand () & 0xFFFF; */
        /* get_entropy((char *)&tmp->ourtid, 2); */
        get_entropy(entropy_buf, 2);
        {
            unsigned short *temp;
            temp = (unsigned short *)entropy_buf;
            tmp->ourtid = *temp & 0xFFFF;
#ifdef DEBUG_ENTROPY
            l2tp_log(LOG_DEBUG, "ourtid = %u, entropy_buf = %hx\n", tmp->ourtid, *temp);
#endif
        }

#else
    tmp->ourtid = 0x6227;
#endif
    tmp->nego = 0;
    tmp->count = 0;
    tmp->state = 0;             /* Nothing */
    tmp->peer.sin_family = AF_INET;
    tmp->peer.sin_port = 0;
    bzero (&(tmp->peer.sin_addr), sizeof (tmp->peer.sin_addr));
#ifdef SANITY
    tmp->sanity = -1;
#endif
    tmp->qtid = -1;
    tmp->ourfc = ASYNC_FRAMING | SYNC_FRAMING;
    tmp->ourbc = 0;
    tmp->ourtb = (((_u64) rand ()) << 32) | ((_u64) rand ());
    tmp->fc = -1;               /* These really need to be specified by the peer */
    tmp->bc = -1;               /* And we want to know if they forgot */
    tmp->hostname[0] = 0;
    tmp->vendor[0] = 0;
    tmp->secret[0] = 0;
    if (!(tmp->self = new_call (tmp)))
    {
        free (tmp);
        return NULL;
    };
    tmp->ourrws = DEFAULT_RWS_SIZE;
    tmp->self->ourfbit = FBIT;
    tmp->lac = NULL;
    tmp->chal_us.state = 0;
    tmp->chal_us.secret[0] = 0;
    memset (tmp->chal_us.reply, 0, MD_SIG_SIZE);
    tmp->chal_us.challenge = NULL;
    tmp->chal_us.chal_len = 0;
    tmp->chal_them.state = 0;
    tmp->chal_them.secret[0] = 0;
    memset (tmp->chal_them.reply, 0, MD_SIG_SIZE);
    tmp->chal_them.challenge = NULL;
    tmp->chal_them.chal_len = 0;
    tmp->chal_them.vector = (unsigned char *) zalloc (VECTOR_SIZE);
    tmp->chal_us.vector = NULL;
    tmp->hbit = 0;
    return tmp;
}

int manager_active() {
	int iwaitstatus, iret;
	
	if( manager_pid != -1 ) {
		if( (iret = waitpid(manager_pid, &iwaitstatus, WNOHANG)) == 0 ) return 1;
		else if( iret != -1 && !WIFEXITED(iwaitstatus) && !WIFSIGNALED(iwaitstatus) ) return 1;
		
		manager_pid = -1;
	}
				
	return 0;
}


void l2tp_wait_socket() {
	while( 1 ) {
		if( !manager_active() ) break;
		if( segptr->ifd > 0 || segptr->ifd == -2 ) break;
		usleep(50000);
	} 
}

int l2tp_get_socket() {
	int flags;
   struct sockaddr_pppol2tp sax;
   
   if( isock_fd != -1 ) return isock_fd;
   if( segptr->ifd < 0 ) return -1;
   
   isock_fd = socket(AF_PPPOX, SOCK_DGRAM, PX_PROTO_OL2TP);
   if( isock_fd < 0 ) {
		l2tp_log (LOG_WARNING, "%s: Unable to allocate PPPoL2TP socket.\n",
			__FUNCTION__);
		
		isock_fd = -1;
		return -2;
   }
   
   flags = fcntl(isock_fd, F_GETFL);
   if( flags == -1 || fcntl(isock_fd, F_SETFL, flags | O_NONBLOCK) == -1 ) {
    	l2tp_log (LOG_WARNING, "%s: Unable to set PPPoL2TP socket nonblock.\n",
    			__FUNCTION__);
		close(isock_fd);
		isock_fd = -1;
    	return -3;
   }
    
   sax.sa_family = AF_PPPOX;
   sax.sa_protocol = PX_PROTO_OL2TP;
   sax.pppol2tp.pid = 0;
   sax.pppol2tp.fd = segptr->ifd;
   sax.pppol2tp.addr.sin_addr.s_addr = segptr->ipv4_addr;
   sax.pppol2tp.addr.sin_port = segptr->port;
   sax.pppol2tp.addr.sin_family = AF_INET;
   sax.pppol2tp.s_tunnel  = segptr->ourtid;
   sax.pppol2tp.s_session = segptr->ourcid;
   sax.pppol2tp.d_tunnel  = segptr->tid;
   sax.pppol2tp.d_session = segptr->cid;
   if( connect(isock_fd, (struct sockaddr *)&sax, sizeof(sax)) < 0 ) {
    	l2tp_log (LOG_WARNING, "%s: Unable to connect PPPoL2TP socket.\n",
    			__FUNCTION__);

		close(isock_fd);
		isock_fd = -1;
		return -4;
   }
   
   close_network();

	return isock_fd;
}

void on_term(int isig) {
	stop_pppd(-1);
}

int l2tp_init(char *lns) {
    struct lac *lac;
    struct in_addr listenaddr;
    struct tunnel *t;
    pid_t fpid;
    int itry;
    
    key = ftok(CONFIG_SEM_KEY_FILE, 0);
    srand( time(NULL) );
    rand_source = 0;

    init_config(lns);
    init_tunnel_list(&tunnels);

	if(init_network())
		return -1;

	switch( (fpid = fork()) ) {
		case -1:
			close_network();
			return -1;
		case 0:
			control_pid = getppid();
		break;
		default:
			manager_pid = fpid; 
			if( (shmid = shmget(key, sizeof(SHT), IPC_CREAT|IPC_EXCL|0666)) == -1 ) {
				l2tp_log (LOG_DEBUG, "%s: %s\n", __FUNCTION__, strerror(errno));
				if( (shmid = shmget(key, sizeof(SHT), 0)) == -1 )  {
					l2tp_log (LOG_DEBUG, "%s: %s\n", __FUNCTION__, strerror(errno));
					close_network();
					return -1;
				}
			}
			if( (segptr = (PSHT)shmat(shmid, 0, 0)) == (int*)-1 ) {
				segptr = NULL;
				shmctl(shmid, IPC_RMID, 0);
				close_network();
				return -1;
			}
			segptr->ifd = -1; /* wait for manager */
			return 0;
	}

	/* manager part */
	itry = 0;
	while( ++itry < 20 ) { /* average 1 sec */
		if( (shmid = shmget(key, sizeof(SHT), 0)) != -1 ) {
			segptr = (PSHT)shmat(shmid, 0, 0);
			break;
		}
		usleep(50000);
	}

	if(segptr == (PSHT)-1) {
		close_network();
		exit(-112);
	}

	init_scheduler ();

	l2tp_log (LOG_INFO, "l2tp version " SERVER_VERSION " started on %s PID:%d\n",
				hostname, getpid ());
	
	listenaddr.s_addr = gconfig.listenaddr;

	lac = laclist;
	
	if (lac) {
#ifdef DEBUG_MAGIC
		l2tp_log (LOG_DEBUG, "%s: Autodialing '%s'\n", __FUNCTION__,
					lac->entname[0] ? lac->entname : "(unnamed)");
#endif

		lac->active = -1;
		
		magic_lac_dial(lac);
		
	}
	
	signal(SIGTERM, on_term);
	signal(SIGINT, on_term);
	signal(SIGHUP, on_term);
	
	network_thread();
	
	if( (t = tunnels.head) ) 
		lac_disconnect(t->ourtid);

	shmdt(segptr);
	close_network();

	exit(0);
	return 0;
}

void l2tp_exit() {
	 int itry;
    
    if( isock_fd != -1 ) {
        close(isock_fd);
        isock_fd = -1;
    }
    
    close_network();
    
	 if( manager_active() ) {
		 kill(manager_pid, SIGHUP);
		 
		 itry = 0;
		 while( ++itry < 20 ) { /* average 1 sec */
			 if( !manager_active() ) break;
			 usleep(50000);
		 }
		 
		 if( manager_active() ) kill(manager_pid, SIGKILL);
	 }
    
    if( segptr ) {
		shmdt(segptr);
		shmctl(shmid, IPC_RMID, 0);
		segptr = NULL;
	}
}

/* Route manipulation */

static int
route_ctrl(int ctrl, struct rtentry *rt)
{
	int s;

	/* Open a raw socket to the kernel */
	if ((s = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ||	ioctl(s, ctrl, rt) < 0)
		l2tp_log (LOG_ERR, "route_ctrl: %s", strerror(errno));
	else errno = 0;

	close(s);
	return errno;
}

int
route_del(struct rtentry *rt)
{
	if (rt->rt_dev) {
		route_ctrl(SIOCDELRT, rt);
		free(rt->rt_dev);
		rt->rt_dev = NULL;
	}
	return 0;
}

int
route_add(const struct in_addr inetaddr, struct rtentry *rt)
{
	char buf[256], dev[64];
	int metric, flags;
	u_int32_t dest, mask;

	int fd;
	struct sockaddr_in mask_s, ipaddr_s;
	struct ifreq ifr;

	FILE *f = fopen("/proc/net/route", "r");
	if (f == NULL) {
	        l2tp_log (LOG_ERR, "/proc/net/route: %s", strerror(errno));
		return -1;
	}

//nickulin
#if 1
	while (fgets(buf, sizeof(buf), f)) 
	{
		if (sscanf(buf, "%63s %x %x %X %*s %*s %d %x", dev, &dest,
		    	&sin_addr(&rt->rt_gateway).s_addr, &flags, &metric, &mask) != 6)
			continue;
		
		if (((flags & RTF_UP) == RTF_UP) && ((inetaddr.s_addr & mask) == dest)) {

			l2tp_log (LOG_INFO, "route_add: have route to host on this dev %s", dev);
			memset((void *)&ifr, 0, sizeof(struct ifreq));
			
			if((fd = socket(AF_INET,SOCK_DGRAM,0)) < 0)	return -1;
			
			strcpy(ifr.ifr_name, dev);

			/*
			 * Определяем IP адрес сетевого интерфейса
			 */
				if(ioctl(fd, SIOCGIFADDR, &ifr) < 0) {
				perror("ioctl SIOCGIFADDR");
				return -1;
				}
				memset((void *)&ipaddr_s, 0, sizeof(struct sockaddr_in));
				memcpy((void *)&ipaddr_s, (void *)&ifr.ifr_addr, sizeof(struct sockaddr));

			/*
			 * Определяем маску подсети
			 */
				if(ioctl(fd, SIOCGIFNETMASK, &ifr) < 0) {
				perror("ioctl SIOCGIFNETMASK");
				return -1;
				}
				memset((void *)&mask_s, 0, sizeof(struct sockaddr_in));
				memcpy((void *)&mask_s, (void *)&ifr.ifr_netmask, sizeof(struct sockaddr));
				
				if ((inetaddr.s_addr & mask_s.sin_addr.s_addr) == (ipaddr_s.sin_addr.s_addr & mask_s.sin_addr.s_addr)) {				
					l2tp_log (LOG_INFO, "route_add: host in same net");
					return 0;
				}
				
		} else continue;
			
		if ((flags & RTF_UP) == RTF_UP && (inetaddr.s_addr & mask) == dest &&
			(dest || strncmp(dev, "ppp", 3)) /* avoid default via pppX to avoid on-demand loops*/)
		{
			rt->rt_metric = metric;
			rt->rt_gateway.sa_family = AF_INET;
			break;
		}
	}
//nickulin
#else
	while (fgets(buf, sizeof(buf), f)) {
		if (sscanf(buf, "%63s %x %x %X %*s %*s %d %x", dev, &dest,
		    	&sin_addr(&rt->rt_gateway).s_addr, &flags, &metric, &mask) != 6)
			continue;
		if ((flags & RTF_UP) == (RTF_UP) && (inetaddr.s_addr & mask) == dest &&
		    (dest || strncmp(dev, "ppp", 3)) /* avoid default via pppX to avoid on-demand loops*/) {
			rt->rt_metric = metric + 1;
			rt->rt_gateway.sa_family = AF_INET;
			break;
		}
	}
#endif
	fclose(f);

	/* check for no route */
	if (rt->rt_gateway.sa_family != AF_INET) {
	        /* l2tp_log (LOG_ERR, "route_add: no route to host"); */
		return -1;
	}

	/* check for existing route to this host, 
	add if missing based on the existing routes */
	if (flags & RTF_HOST) {
	        /* l2tp_log (LOG_ERR, "route_add: not adding existing route"); */
		return -1;
	}

	sin_addr(&rt->rt_dst) = inetaddr;
	rt->rt_dst.sa_family = AF_INET;

	sin_addr(&rt->rt_genmask).s_addr = INADDR_BROADCAST;
	rt->rt_genmask.sa_family = AF_INET;

	rt->rt_flags = RTF_UP | RTF_HOST;
	if (flags & RTF_GATEWAY)
		rt->rt_flags |= RTF_GATEWAY;

	rt->rt_metric++;
	rt->rt_dev = strdup(dev);

	if (!rt->rt_dev) {
	        l2tp_log (LOG_ERR, "route_add: no memory");
		return -1;
	}

	if (!route_ctrl(SIOCADDRT, rt))
		return 0;

	free(rt->rt_dev);
	rt->rt_dev = NULL;

	return -1;
}
