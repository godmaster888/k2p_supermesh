/*
 * Layer Two Tunnelling Protocol Daemon
 * Copyright (C) 1998 Adtran, Inc.
 * Copyright (C) 2002 Jeff McAdams
 *
 * Mark Spencer
 *
 * This software is distributed under the terms
 * of the GPL, which you should have received
 * along with this source.
 *
 * File format handling
 *
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <netdb.h>
#include <netinet/in.h>
#include <time.h>
#include <sys/types.h>
#include <sys/socket.h>

#include "l2tp.h"

struct lac *laclist;
struct global gconfig;

struct lac *new_lac ()
{
    struct lac *tmp;
    tmp = (struct lac *) zalloc (sizeof (struct lac));
    if (!tmp)
    {
        l2tp_log (LOG_CRIT, "%s: Unable to allocate memory for lac entry!\n",
             __FUNCTION__);
        return NULL;
    }
    tmp->rsched = NULL;
    tmp->lns = 0;
    tmp->tun_rws = 4;
    tmp->call_rws = 10;
    tmp->hbit = 0;
    tmp->lbit = 0;
    tmp->t = NULL;
    tmp->challenge = 0;
    tmp->active = 0;
    return tmp;
}



int init_config (char *lns) {
    char *port;
    
    gconfig.port = UDP_LISTEN_PORT;
    gconfig.listenaddr = htonl(INADDR_ANY); /* Default is to bind (listen) to all interfaces */
    gconfig.debug_avp = 0;
    gconfig.debug_network = 0;
    gconfig.packet_dump = 0;
    gconfig.debug_tunnel = 0;
    gconfig.debug_state = 0;
    gconfig.ipsecsaref = 0;

    if( (laclist = new_lac()) ) {
	if( !(laclist->lns = (struct host*)zalloc(sizeof(struct host))) ) {
	    l2tp_log (LOG_CRIT, "%s: Unable to allocate memory for lns entry!\n",
             __FUNCTION__);
	     free(laclist);
	     laclist = NULL;
	     return -1;
	}
	memset(laclist->lns, 0, sizeof(struct host));
	if( (port = strchr(lns, ':')) ) {
	    memcpy(laclist->lns->hostname, lns, MIN((int)(port - lns), (sizeof(laclist->lns->hostname) - 1)));
	    laclist->lns->port = atoi(port + 1);
	} else {
	    strncpy(laclist->lns->hostname, lns, sizeof(laclist->lns->hostname) - 1);
	    laclist->lns->port = UDP_LISTEN_PORT;
	}
    }
    
    return 0;
}

