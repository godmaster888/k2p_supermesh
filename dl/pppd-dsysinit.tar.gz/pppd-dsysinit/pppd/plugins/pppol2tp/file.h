/*
 * Layer Two Tunnelling Protocol Daemon
 * Copyright (C) 1998 Adtran, Inc.
 * Copyright (C) 2002 Jeff McAdams
 *
 * Mark Spencer
 *
 * This software is distributed under the terms
 * of the GPL, which you should have received
 * along with this source.
 *
 * File format handling header file
 *
 */

#ifndef _FILE_H
#define _FILE_H

#define STRLEN 80               /* Length of a string */

struct host
{
    char hostname[STRLEN];
    int port;
};

#define AUTH_FILE "/etc/ppp/l2tp-secrets"

#define CONTEXT_GLOBAL 	1
#define CONTEXT_LNS	   	2
#define CONTEXT_LAC		3
#define CONTEXT_DEFAULT	256

#define SENSE_ALLOW -1
#define SENSE_DENY 0

struct lac
{
    struct host *lns;           /* LNS's we can connect to */
    struct schedule_entry *rsched;
    int tun_rws;                /* Receive window size (tunnel) */
    int call_rws;               /* Call rws */
    int active;                 /* Is this connection in active use? */
    int hbit;                   /* Permit hidden AVP's? */
    int lbit;                   /* Use the length field? */
    int challenge;              /* Challenge authenticate the peer? */
    char peername[STRLEN];      /* Force peer name to this */
    char hostname[STRLEN];      /* Hostname to report */
    char entname[STRLEN];       /* Name of this entry */
    int idle;                   /* Idle timeout in seconds */
    struct tunnel *t;           /* Our tunnel */
    struct call *c;             /* Our call */
};

struct global
{
    unsigned int listenaddr;    /* IP address to bind to */ 
    int port;                   /* Port number to listen to */
    int packet_dump;		/* Dump (print) all packets? */
    int debug_avp;		/* Print AVP debugging info? */
    int debug_network;		/* Print network debugging info? */
    int debug_tunnel;		/* Print tunnel debugging info? */
    int debug_state;		/* Print FSM debugging info? */
    int ipsecsaref;
};

extern struct global gconfig;   /* Global configuration options */

extern struct lac *laclist;     /* All LAC entries */
extern int init_config(char *lns);
#endif
