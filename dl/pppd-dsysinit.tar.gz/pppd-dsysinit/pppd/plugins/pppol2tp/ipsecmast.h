#ifndef _IPSECMAST_H
#define _IPSECMAST_H

#ifndef IP_IPSEC_REFINFO
#define IP_IPSEC_REFINFO 18
#endif

#ifndef IPSEC_SAREF_NULL
typedef uint32_t IPsecSAref_t;

#define IPSEC_SAREF_NULL ((IPsecSAref_t)0)
#endif

#endif
