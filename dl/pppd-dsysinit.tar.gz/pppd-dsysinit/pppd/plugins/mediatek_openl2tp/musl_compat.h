#ifndef MUSL_COMPAT_H
#define MUSL_COMPAT_H

//#18758: не нашлось такого дефайна
//в хидерах мюсли. И вообще, тут мешанина
//хидеров. Исторический треш.

#if defined(MUSL_LIBC)
# ifndef __P
#   if defined(__STDC__) || defined(__GNUC__)
#     define __P(x) x
#   else
#     define __P(x) ()
#   endif
# endif
#endif


#endif
