/* $Id: patchlevel.h,v 1.66 2006/06/28 00:21:23 paulus Exp $ */

#define VERSION		"2.4.4"
#define DATE		"28 June 2006"
