/*
 * This file is part of improxy.
 *
 * Copyright (C) 2012 by Haibo Xi <haibbo@gmail.com>
 *
 * The program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 * Website: https://github.com/haibbo/improxy
 */

#include <stdio.h>
#include <getopt.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <linux/if.h>
#include <linux/igmp.h>
#include <netinet/ip.h>

#include <arpa/inet.h>
#include "proxy.h"
#include "timer.h"
#include "utils.h"
#include "input.h"
#include "handler.h"
#include "membership.h"
#include "kernel_api.h"

struct imp_multi_rec {
	unsigned char   rec_type;
	unsigned char   aux_len;
	unsigned short  src_num;
	struct in6_addr multi_addr;
	struct in6_addr src_list[0];
};

extern mcast_proxy mproxy;

#define MLD_MODE_IS_INCLUDE        1
#define MLD_MODE_IS_EXCLUDE        2
#define MLD_CHANGE_TO_INCLUDE    3
#define MLD_CHANGE_TO_EXCLUDE    4
#define MLD_ALLOW_NEW_SOURCES    5
#define MLD_BLOCK_OLD_SOURCES    6


#define    IN_LOCAL_CONTROL_BLOCK(a)        ((((unsigned long)(a)) & 0xffffff00) == 0xe0000000)

#define    IN_LOCAL_SCOPE_BLOCK(a)        ((((unsigned long)(a)) & 0xEFFF0000) == 0xEFFF0000)

/**************************************************************************
 * FUNCTION NAME : imp_get_group_if_addr
 **************************************************************************
 * DESCRIPTION   :
 * Get group from p_if accroding to gourp ip information
 *************************************************************************/
static imp_group *imp_get_group_if_addr(imp_interface *p_if, pi_addr *pigp)
{
	imp_group *p_gp = LIST_FIRST(&p_if->group_list);

	if (p_if->type == INTERFACE_UPSTREAM) {
		return NULL;
	}

	while (p_gp) {
		if (memcmp(&p_gp->group_addr, pigp, sizeof(pi_addr)) == 0) {
			return p_gp;
		}

		p_gp = LIST_NEXT(p_gp, link);
	}

	return NULL;
}

static int imp_get_is_forward(imp_interface *p_if, pi_addr *pigp, pi_addr *pip)
{
	imp_source *msp = NULL;
	imp_group    *p_gp;
	struct timeval now;

	get_sysuptime(&now);

	p_gp = imp_get_group_if_addr(p_if, pigp);

	if (p_gp == NULL) {

		return 0;
	}


	if (p_gp->type == GROUP_INCLUDE) {
		for (msp = LIST_FIRST(&p_gp->src_list); msp;
		        msp = LIST_NEXT(msp, link)) {

			if (memcmp(&msp->src_addr, pip, sizeof(pi_addr)) == 0
			        && TIMEVAL_LT(now, msp->timer->tm)) {
				return 1;
			}
		}

		return 0;
	} else if (p_gp->type == GROUP_EXCLUDE) {
		for (msp = LIST_FIRST(&p_gp->src_list); msp;
		        msp = LIST_NEXT(msp, link)) {

			if (memcmp(&msp->src_addr, pip, sizeof(pi_addr)) == 0
			        && TIMEVAL_LT(msp->timer->tm, now)) {
				return 0;
			}
		}

		return 1;
	}

	return 0;
}

static int imp_get_mfcc_ttls(if_set *p_ttls, pi_addr *pi_src, pi_addr *p_group)
{
	imp_interface *p_if = imp_interface_first();
	unsigned char flag = 0;


	if (pi_src->ss.ss_family != p_group->ss.ss_family) {
		IMP_LOG_ERROR("unmatch family");
		return 0;
	}

	while (p_if) {
		if (p_if->type != INTERFACE_UPSTREAM &&
		        imp_get_is_forward(p_if, p_group, pi_src)) {

			int vmif = 0;
			vmif = k_get_vmif(p_if->if_index, p_group->ss.ss_family);
			IF_SET(vmif, p_ttls);
			flag = 1;
		}

		p_if = LIST_NEXT(p_if, link);
	}

	if (flag == 0)
		IMP_LOG_DEBUG("group %s isn't interest in packet from %s\n",
		              imp_pi_ntoa(p_group), imp_pi_ntoa(pi_src));

	return flag;
}


#ifdef ENABLE_IMP_IGMP
static imp_interface *mcast_if_get_by_addr(pi_addr *p_pia)
{
	imp_interface *p_if = imp_interface_first();

	while (p_if) {

		if (memcmp(&p_if->if_addr, p_pia, sizeof(pi_addr)) == 0) {
			return p_if;
		}

		p_if = LIST_NEXT(p_if, link);
	}

	return NULL;
}

static int imp_verify_v4multicast_addr(pi_addr *p_pia)
{
	if (p_pia->ss.ss_family != AF_INET)
		return -1;

	if (!IN_MULTICAST(ntohl(p_pia->v4.sin_addr.s_addr))) {
		IMP_LOG_ERROR("group address %s isn't multicast adddress\n", imp_pi_ntoa(p_pia));
		return -1;
	}

	/*
	 *    Address Range                 Size       Designation
	 *    -------------                 ----       -----------
	 *    224.0.0.0 - 224.0.0.255       (/24)      Local Network Control Block
	 *
	 *    Addresses in the Local Network Control Block are used for protocol
	 *    control traffic that is not forwarded off link.
	 *    [RFC 5771 section 4]
	 */
	if (IN_LOCAL_CONTROL_BLOCK(ntohl(p_pia->v4.sin_addr.s_addr))) {
		IMP_LOG_INFO("Group address %s is Local Network Control Block\n", imp_pi_ntoa(p_pia));
		return -1;
	}

	/* 239.255.0.0/16 is defined to be the IPv4 Local Scope.
	 * [RFC 2365 section 6.1]
	 */
	if (IN_LOCAL_SCOPE_BLOCK(ntohl(p_pia->v4.sin_addr.s_addr))) {
		IMP_LOG_INFO("Group address %s belongs to IPv4 Local Scope.\n", imp_pi_ntoa(p_pia));
		return -1;
	}

	return 0;

}

/* Handler for IGMPv1/IGMPv2 Reports */
static void imp_input_report_v1v2(imp_interface *p_if, struct igmphdr *igh)
{
	pi_addr pig;

	imp_build_piaddr(AF_INET, &igh->group, &pig);

	IMP_LOG_DEBUG("group address %s\n", imp_pi_ntoa(&pig));

	if (imp_verify_v4multicast_addr(&pig) < 0) {
		return;
	}

	switch (igh->type) {

	case IGMP_HOST_MEMBERSHIP_REPORT:
		mcast_is_ex_hander(p_if, &pig, NULL, IM_IGMPv1);
		break;

	case IGMPV2_HOST_MEMBERSHIP_REPORT:
		mcast_is_ex_hander(p_if, &pig, NULL, IM_IGMPv2_MLDv1);
		break;

	case IGMP_HOST_LEAVE_MESSAGE:
		mcast_to_in_handler(p_if, &pig, NULL, IM_IGMPv2_MLDv1);
		break;
	}

	imp_membership_db_update(&pig);
}

/* Handler for IGMPv3 Reports */
static void imp_input_report_v3(imp_interface *p_if, struct igmpv3_report *p_ig3h, int buf_len)
{
	int     i = 0;
	pi_addr pig;
	int     cur_len = 0;

	cur_len  += sizeof(struct igmpv3_report);

	IMP_LOG_DEBUG("type : 0x%x\n num p_grec %d\n", p_ig3h->type, ntohs(p_ig3h->ngrec));

	for (; i < ntohs(p_ig3h->ngrec); i++) {

		struct igmpv3_grec *p_grec = NULL;
		pa_list            *p_src_list = NULL;
		int                 k;

		p_grec = (struct igmpv3_grec *)((char *)p_ig3h + cur_len);

		cur_len += (ntohs(p_grec->grec_nsrcs) * sizeof(int) + sizeof(struct igmpv3_grec));

		if (cur_len > buf_len) {

			IMP_LOG_ERROR("exceed buffer\n");
			return;
		}

		imp_build_piaddr(AF_INET, &p_grec->grec_mca, &pig);
		IMP_LOG_DEBUG("group is = %s\n", imp_pi_ntoa(&pig));

		if (imp_verify_v4multicast_addr(&pig) < 0) {
			continue;
		}

		IMP_LOG_DEBUG("number of source = %d\n", ntohs(p_grec->grec_nsrcs));

		for (k = 0; k < ntohs(p_grec->grec_nsrcs); k++) {

			pi_addr pa;
			imp_build_piaddr(AF_INET, &p_grec->grec_src[k], &pa);
			p_src_list = pa_list_add(p_src_list, &pa);
		}

		switch (p_grec->grec_type) {

		case IGMPV3_MODE_IS_INCLUDE:
			IMP_LOG_DEBUG("IGMPV3_MODE_IS_INCLUDE\n");
			mcast_is_in_handler(p_if, &pig, p_src_list, IM_IGMPv3_MLDv2);
			break;

		case IGMPV3_MODE_IS_EXCLUDE:
			IMP_LOG_DEBUG("IGMPV3_MODE_IS_EXCLUDE\n");
			mcast_is_ex_hander(p_if, &pig, p_src_list, IM_IGMPv3_MLDv2);
			break;

		case IGMPV3_CHANGE_TO_INCLUDE:
			/*leave */
			IMP_LOG_DEBUG("IGMPV3_CHANGE_TO_INCLUDE\n");
			mcast_to_in_handler(p_if, &pig, p_src_list, IM_IGMPv3_MLDv2);
			break;

		case IGMPV3_CHANGE_TO_EXCLUDE:
			/*join*/
			IMP_LOG_DEBUG("IGMPV3_CHANGE_TO_EXCLUDE\n");
			mcast_to_ex_hander(p_if, &pig, p_src_list, IM_IGMPv3_MLDv2);
			break;

		case IGMPV3_ALLOW_NEW_SOURCES:
			IMP_LOG_DEBUG("IGMPV3_ALLOW_NEW_SOURCES\n");
			mcast_allow_handler(p_if, &pig, p_src_list, IM_IGMPv3_MLDv2);
			break;

		case IGMPV3_BLOCK_OLD_SOURCES:
			IMP_LOG_DEBUG("IGMPV3_BLOCK_OLD_SOURCES\n");
			mcast_block_handler(p_if, &pig, p_src_list, IM_IGMPv3_MLDv2);
			break;

		default:
			IMP_LOG_ERROR("error group type\n");
			pa_list_cleanup(&p_src_list);
			return;
		}

		imp_membership_db_update(&pig);
		pa_list_cleanup(&p_src_list);

	}
}

/* Handler for Pseudo IGMP packets from Kernel */
static void handle_input_mrtmsg(struct igmpmsg *im_msg)
{
	pi_addr pig, pia;
	int up_vif = k_get_vmif(get_up_if_index(), AF_INET);

	if (up_vif != im_msg->im_vif) {
		IMP_LOG_WARNING("igmp: recv igmpmsg from non-upstream VIF: %d: drop\n",
		                im_msg->im_vif);
		return;

	}

	if (im_msg->im_msgtype != IGMPMSG_NOCACHE) {
		IMP_LOG_WARNING("igmp: recv igmpmsg with unsupported type: %u: drop\n",
		                im_msg->im_msgtype);
		return;
	}

	if_set ttls = {0};

	imp_build_piaddr(AF_INET, &im_msg->im_dst, &pig);
	imp_build_piaddr(AF_INET, &im_msg->im_src, &pia);

	if (imp_get_mfcc_ttls(&ttls, &pia, &pig) == 0) {
		return;
	}

	/* TODO: imp_pi_ntoa is broken, it uses a static buffer */
	IMP_LOG_DEBUG("igmp: add MFC: src = %s\n", imp_pi_ntoa(&pia));
	IMP_LOG_DEBUG("igmp: add MFC: group = %s\n", imp_pi_ntoa(&pig));
	IMP_LOG_DEBUG("igmp: add MFC: vif = %d\n", up_vif);
	imp_membership_db_mfc_add(&pig, &pia, &ttls);
}

/* Handler for ALL IGMP Reports */
static void handle_input_igmp_report(struct igmphdr *igmph, ssize_t igmph_len, imp_interface *p_if)
{
	int version = mproxy.igmp_version;

	switch (igmph->type) {
	case IGMP_HOST_MEMBERSHIP_REPORT:
		imp_input_report_v1v2(p_if, igmph);
		break;

	case IGMP_HOST_LEAVE_MESSAGE:
	case IGMPV2_HOST_MEMBERSHIP_REPORT:
		if (version < IM_IGMPv2_MLDv1) {
			IMP_LOG_WARNING("Don't support IGMPv2, " \
			                "current version is IGMPv%d\n", version);
			return;
		}

		imp_input_report_v1v2(p_if, igmph);
		break;

	case IGMPV3_HOST_MEMBERSHIP_REPORT:
		if (version < IM_IGMPv3_MLDv2) {
			IMP_LOG_WARNING("Don't support IGMPv3, " \
			                "current version is igmpv%d\n", version);
			return;
		}

		imp_input_report_v3(p_if, (struct igmpv3_report *)igmph, igmph_len);
		break;

	default:
		IMP_LOG_WARNING("igmp: unsupported IGMP type: 0x%x\n", igmph->type);
		break;
	}
}

/* Handler for ALL IGMP packets */
void mcast_recv_igmp(void)
{
	unsigned char buf[MAX_RECV_BUF_LEN];
	unsigned char cbuf[CMSG_SPACE(sizeof(struct in_pktinfo))];
	struct sockaddr sa;
	pi_addr pia;

	struct iovec iov = {
		.iov_base = buf,
		.iov_len = sizeof(buf)
	};

	struct msghdr msg = {
		.msg_name = &sa,
		.msg_namelen = sizeof(sa),
		.msg_iov = &iov,
		.msg_iovlen = 1,
		.msg_control = cbuf,
		.msg_controllen = sizeof(cbuf),
	};

	ssize_t rcvlen = recvmsg(get_igmp_mld_socket(AF_INET), &msg, 0);

	if (rcvlen < 0) {
		/* TODO: add error checking for EINTR if we disable SA_RESTART */
		IMP_LOG_ERROR("igmp: recvmsg failed: %s\n", strerror(errno));
		return;
	}

	struct iphdr *iph = iov.iov_base;

	if (rcvlen <= (ssize_t)sizeof(*iph)) {
		IMP_LOG_ERROR("igmp: ip pkt with invalid size: %zd: drop\n", rcvlen);
		return;
	}

	if (iph->protocol == 0) {
		handle_input_mrtmsg(iov.iov_base);
		return;
	}

	/* get source address */
	imp_build_piaddr(AF_INET, &iph->saddr, &pia);
	IMP_LOG_DEBUG("igmp: receive pkt from %s\n", imp_pi_ntoa(&pia));

	/* get VIF */
	int if_index = 0;

	for (struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msg); cmsg; cmsg = CMSG_NXTHDR(&msg, cmsg)) {

		if (cmsg->cmsg_level == IPPROTO_IP && cmsg->cmsg_type == IP_PKTINFO) {
			struct in_pktinfo *info = (struct in_pktinfo *)CMSG_DATA(cmsg);
			if_index = info->ipi_ifindex;
		}
	}

	imp_interface *p_if = imp_interface_by_ifindex(AF_INET, if_index);

	if (!p_if) {
		IMP_LOG_ERROR("igmp: not found VIF for interface %d: drop\n", if_index);
		return;
	}

	if (mcast_if_get_by_addr(&pia) != NULL) {
		IMP_LOG_DEBUG("igmp: packet from myself: drop\n");
		return;
	}

	ssize_t iph_len = iph->ihl * 4;
	ssize_t igmp_len = rcvlen - iph_len;

	if (igmp_len <= 0) {
		IMP_LOG_ERROR("igmp: ip pkt without payload: drop\n");
		return;
	}

	struct igmphdr *igmph  = (struct igmphdr *)&buf[iph_len];

	if (in_cusm((unsigned short *)igmph, igmp_len) != 0) {
		IMP_LOG_ERROR("igmp: packet has invalid checksum: drop\n");
		return;
	}

	/* validate igmp packet */
	if (iph->ttl != 1) {
		IMP_LOG_WARNING("igmp: packet (type 0x%x) has TTL not equal 1: drop\n",
		                igmph->type);
		return;
	}

	if (igmph->type == IGMP_HOST_MEMBERSHIP_QUERY) {
		IMP_LOG_DEBUG("igmp: query received: we don't process it now: drop\n");
		return;
	}

	if (igmph->type != IGMP_HOST_MEMBERSHIP_REPORT && iph_len < 24) {
		/* TODO: check router alert */
		IMP_LOG_WARNING("igmp: packet (type 0x%x) without RTR-ALERT option: drop\n",
		                igmph->type);
		return;
	}

	handle_input_igmp_report(igmph, igmp_len, p_if);
}
#endif /* ENABLE_IMP_IGMP */

#ifdef ENABLE_IMP_MLD
static int imp_verify_v6multicast_addr(pi_addr *p_pia)
{
	if (p_pia->ss.ss_family != AF_INET6)
		return -1;

	if (!IN6_IS_ADDR_MULTICAST(p_pia->v6.sin6_addr.s6_addr)) {
		IMP_LOG_ERROR("Address %s isn't multicast address\n", imp_pi_ntoa(p_pia));
		return -1;
	}

	/* Interface-Local scope spans only a single interface on a node
	 * and is useful only for loopback transmission of multicast.
	 *
	 * Link-Local multicast scope spans the same topological region as
	 * the corresponding unicast scope.
	 * [RFC 4291 section 2.7]
	 */

	if (IN6_IS_ADDR_MC_LINKLOCAL(p_pia->v6.sin6_addr.s6_addr) ||
			IN6_IS_ADDR_MC_NODELOCAL(p_pia->v6.sin6_addr.s6_addr)) {
		IMP_LOG_WARNING("Group address %s is link-local multicast address\n", imp_pi_ntoa(p_pia));
		return -1;
	}

	/*
	 * Nodes must not originate a packet to a multicast address whose scop
	 * field contains the reserved value 0; if such a packet is received, it
	 * must be silently dropped.  Nodes should not originate a packet to a
	 * multicast address whose scop field contains the reserved value F; if
	 * such a packet is sent or received, it must be treated the same as
	 * packets destined to a global (scop E) multicast address.
	 * [RFC 4291 section 2.7]
	 */
	if ((p_pia->v6.sin6_addr.s6_addr[1] & 0x0f) == 0) {
		IMP_LOG_WARNING("group address %s's scope is 0, Ignore it.\n", imp_pi_ntoa(p_pia));
		return -1;
	}

	return 0;
}

/* Handler for MLDv1 Reports */
static void imp_input_report_mld(imp_interface  *p_if, struct mld_hdr *p_mldhr)
{
	pi_addr pig;

	imp_build_piaddr(AF_INET6, &p_mldhr->mld_addr, &pig);

	if (imp_verify_v6multicast_addr(&pig) < 0) {
		return;
	}

	IMP_LOG_DEBUG("test %s\n", imp_pi_ntoa(&pig));

	switch (p_mldhr->mld_type) {

	case MLD_LISTENER_REPORT:
		mcast_is_ex_hander(p_if, &pig, NULL, IM_IGMPv2_MLDv1);
		break;

	case MLD_LISTENER_REDUCTION:
		mcast_to_in_handler(p_if, &pig, NULL, IM_IGMPv2_MLDv1);
		break;
	}

	imp_membership_db_update(&pig);
	return;

}

/* Handler for MLDv2 Reports */
static void imp_input_report_mldv2(imp_interface *p_if, struct mld_hdr *p_mldh, int buf_len)
{
	int i = 0, num = 0, cur_len = 0;
	pi_addr pig;

	num =  ntohs(p_mldh->mld_num_multi);
	cur_len += sizeof(struct icmp6_hdr);

	for (; i < num; i++) {

		struct imp_multi_rec *p_rec = (struct imp_multi_rec *)((char *)p_mldh + cur_len);
		pa_list *p_src_list = NULL;
		int k;

		imp_build_piaddr(AF_INET6, &p_rec->multi_addr, &pig);
		IMP_LOG_DEBUG("group is = %s\n", imp_pi_ntoa(&pig));

		if (imp_verify_v6multicast_addr(&pig) < 0) {
			continue;
		}

		cur_len += (ntohs(p_rec->src_num) * sizeof(struct in6_addr) +
		            sizeof(struct imp_multi_rec));

		if (cur_len > buf_len) {

			IMP_LOG_ERROR("exceed buffer\n");
			return;
		}

		for (k = 0; k < ntohs(p_rec->src_num); k++) {

			pi_addr pa;
			imp_build_piaddr(AF_INET6, &p_rec->src_list[k], &pa);
			p_src_list = pa_list_add(p_src_list, &pa);
		}

		switch (p_rec->rec_type) {

		case MLD_MODE_IS_INCLUDE:
			IMP_LOG_INFO("MLD_MODE_IS_INCLUDE\n");
			mcast_is_in_handler(p_if, &pig, p_src_list, IM_IGMPv3_MLDv2);
			break;

		case MLD_MODE_IS_EXCLUDE:
			IMP_LOG_INFO("MLD_MODE_IS_EXCLUDE\n");
			mcast_is_ex_hander(p_if, &pig, p_src_list, IM_IGMPv3_MLDv2);
			break;

		case MLD_CHANGE_TO_INCLUDE:
			/*leave */
			IMP_LOG_INFO("MLD_CHANGE_TO_INCLUDE\n");
			mcast_to_in_handler(p_if, &pig, p_src_list, IM_IGMPv3_MLDv2);
			break;

		case MLD_CHANGE_TO_EXCLUDE:
			/*join*/
			IMP_LOG_INFO("MLD_CHANGE_TO_EXCLUDE\n");
			mcast_to_ex_hander(p_if, &pig, p_src_list, IM_IGMPv3_MLDv2);
			break;

		case MLD_ALLOW_NEW_SOURCES:
			IMP_LOG_INFO("MLD_ALLOW_NEW_SOURCES\n");
			mcast_allow_handler(p_if, &pig, p_src_list, IM_IGMPv3_MLDv2);
			break;

		case MLD_BLOCK_OLD_SOURCES:
			IMP_LOG_INFO("MLD_BLOCK_OLD_SOURCES\n");
			mcast_block_handler(p_if, &pig, p_src_list, IM_IGMPv3_MLDv2);
			break;

		default:
			IMP_LOG_ERROR("error group type\n");
			pa_list_cleanup(&p_src_list);
			return;
		}

		imp_membership_db_update(&pig);
		pa_list_cleanup(&p_src_list);

	}
}

/* Handler for Pseudo MLD packets from Kernel */
static void handle_input_mrt6msg(struct mrt6msg *im6_msg)
{
	pi_addr pig, pia;
	int up_mif = k_get_vmif(get_up_if_index(), AF_INET6);

	if (up_mif != im6_msg->im6_mif) {
		IMP_LOG_WARNING("mld: recv mrt6msg from non-upstream MIF: %d: drop\n",
		                im6_msg->im6_mif);
		return;
	}


	if (im6_msg->im6_msgtype != MRT6MSG_NOCACHE) {
		IMP_LOG_WARNING("mld: recv mrt6smg with unsupported type: %u: drop\n",
		                im6_msg->im6_msgtype);
		return;
	}

	if_set ttls = {0};

	imp_build_piaddr(AF_INET6, &im6_msg->im6_dst, &pig);
	imp_build_piaddr(AF_INET6, &im6_msg->im6_src, &pia);

	if (imp_get_mfcc_ttls(&ttls, &pia, &pig) == 0) {
		return;
	}

	/* TODO: imp_pi_ntoa is broken, it uses a static buffer */
	IMP_LOG_DEBUG("mld: add MFC: src = %s\n", imp_pi_ntoa(&pia));
	IMP_LOG_DEBUG("mld: add MFC: group = %s\n", imp_pi_ntoa(&pig));
	IMP_LOG_DEBUG("mld: add MFC: mif = %d\n", up_mif);
	imp_membership_db_mfc_add(&pig, &pia, &ttls);
}

/* Handler for ALL MLD Reports */
static void handle_input_mld_report(struct mld_hdr *mldh, size_t mld_len, imp_interface *p_if)
{ 
	int version = mproxy.mld_version;

	switch (mldh->mld_type) {
	case MLD_LISTENER_REPORT:
	case MLD_LISTENER_REDUCTION:
		imp_input_report_mld(p_if, mldh);
		break;

	case MLD_V2_LISTENER_REPORT:
		if (version < IM_IGMPv3_MLDv2) {
			IMP_LOG_WARNING("Don't support MLDv2, " \
			                "current version is MLDv%d\n", version - 1);
			return;
		}

		imp_input_report_mldv2(p_if, mldh, mld_len);
		break;

	default:
		IMP_LOG_WARNING("mld: unsupported ICMPv6 type: %d\n", mldh->mld_type);
		break;
	}
}

/* Handler for ALL MLD packets */
void mcast_recv_mld(void)
{
	unsigned char buf[MAX_RECV_BUF_LEN];
	unsigned char cbuf[128]; /* TODO: add size calculation */
	struct sockaddr_in6 sa;
	pi_addr pia;

	struct iovec iov = {
		.iov_base = buf,
		.iov_len = sizeof(buf)
	};

	struct msghdr msg = {
		.msg_name = &sa,
		.msg_namelen = sizeof(sa),
		.msg_iov = &iov,
		.msg_iovlen = 1,
		.msg_control = cbuf,
		.msg_controllen = sizeof(cbuf),
	};

	ssize_t rcvlen = recvmsg(get_igmp_mld_socket(AF_INET6), &msg, MSG_WAITALL);

	if (rcvlen < 0) {
		/* TODO: add error checking for EINTR, if we disable SA_RESTART */
		IMP_LOG_ERROR("mld: recvmsg failed: %s\n", strerror(errno));
		return;
	}

	struct mld_hdr *mldh = iov.iov_base;

	if (rcvlen < (ssize_t)sizeof(*mldh)) {
		IMP_LOG_ERROR("mld: pkt with invalid size: %zd: drop\n", rcvlen);
		return;
	}

	if (mldh->mld_type == 0) {
		handle_input_mrt6msg(iov.iov_base);
		return;
	}

	/* get source address */
	imp_build_piaddr(AF_INET6, &sa.sin6_addr, &pia);
	IMP_LOG_DEBUG("Recv mld pkt from %s\n", imp_pi_ntoa(&pia));

	/* get MIF */
	int if_index = sa.sin6_scope_id;
	imp_interface *p_if = imp_interface_by_ifindex(AF_INET6, if_index);

	if (!p_if) {
		IMP_LOG_ERROR("mld: not found MIF for interface: %s: drop\n", if_index);
		return;
	}

	/* validate mld packet */
	int with_rtr_alert = 0;
	int hop_limit = 0;

	for (struct cmsghdr *cmsg = CMSG_FIRSTHDR(&msg); cmsg; cmsg = CMSG_NXTHDR(&msg, cmsg)) {

		if (cmsg->cmsg_level != IPPROTO_IPV6) {
			continue;
		}

		switch (cmsg->cmsg_type) {
		case IPV6_HOPLIMIT:
			memcpy(&hop_limit, CMSG_DATA(cmsg), sizeof(hop_limit));
			break;

		case IPV6_HOPOPTS:
			/* TODO: add router-alert option verification
			 * memmem could work incorrectly */
			with_rtr_alert = 1;
			break;
		}
	}

	/* Upon reception of an MLD message that contains a Report,
	 * the router checks:
	 *
	 * 1. if the source address of the message is a valid link-local address
	 * 2. if the Hop Limit is set to 1
	 * 3. if the Router Alert option is present
	 *
	 * If any of these checks fails, the packet is dropped.
	 *
	 * [RFC 3810, 7.4]
	 */

	if (!IN6_IS_ADDR_LINKLOCAL(&sa.sin6_addr)) {
		IMP_LOG_ERROR("mld: src address of report is not link-local: %s: drop\n",
		              imp_pi_ntoa(&pia));
		return;
	}

	if (hop_limit != 1) {
		IMP_LOG_ERROR("mld: report's Hop Limit is not equal 1: drop\n");
		return;
	}

	if (!with_rtr_alert) {
		IMP_LOG_ERROR("mld: report without RTR-ALERT option: drop\n");
		return;
	}

	handle_input_mld_report(mldh, rcvlen, p_if);
}
#endif /* ENABLE_IMP_MLD */
