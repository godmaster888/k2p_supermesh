/*
 * This file is part of improxy.
 *
 * Copyright (C) 2012 by Haibo Xi <haibbo@gmail.com>
 *
 * The program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * The program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 * Website: https://github.com/haibbo/improxy
 */

#include "proxy.h"
#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <netinet/icmp6.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <linux/if.h>
#include <signal.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

#include "timer.h"
#include "utils.h"
#include "input.h"
#include "handler.h"
#include "kernel_api.h"
#include "data.h"
#include "membership.h"

mcast_proxy mproxy;
char    pid_file[1024] = {0};

#ifdef ENABLE_IMP_IGMP
#define IGMP_ALL_ROUTERS        0xE0000002
#define IGMP_ALL_ROUTERS_V3     0xE0000016
#endif

#ifdef ENABLE_IMP_MLD
unsigned char MLD_ALL_ROUTERS[] = {0xff, 0x2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x2};
unsigned char MLD_ALL_ROUTERS_V3[] = {0xff, 0x2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x16};
#endif


static STATUS load_config(const char *file)
{
	FILE    *fd;
	char    buffer[1024] = {0};
	char    downinf[10][IFNAMSIZ], upinf[IFNAMSIZ];
	int     down_num, i;
	STATUS status = STATUS_NOK;

	down_num = 0;
	memset(downinf, 0, 10 * IFNAMSIZ);
	memset(upinf, 0, IFNAMSIZ);

	fd = fopen(file, "r");

	if (fd == NULL) {
		IMP_LOG_ERROR("%s\n", strerror(errno));
		exit(EXIT_FAILURE);
	}

	while (fgets(buffer, 1024, fd)) {
		char  *p_token, *p_value;

		if (strchr(buffer, '\n')) {
			*(strchr(buffer, '\n')) = '\0';
		}

		IMP_LOG_DEBUG("buffer = %s\n", buffer);
		p_token = buffer + strspn(buffer, " \t");

		if (*p_token == '#' || *p_token == '\0') {
			IMP_LOG_DEBUG("need continue\n");
			continue;
		}

		p_token = strtok(p_token, " \t");

		if (p_token == NULL) {
			continue;
		}

		p_value = strtok(NULL, " \t");

		if (p_value == NULL) {

			IMP_LOG_DEBUG("%s don't have value\n", p_token);
			goto out_error;
		}

		IMP_LOG_DEBUG("token is %s\n", p_token);
#ifdef ENABLE_IMP_IGMP
		if (strcmp(p_token, "igmp") == 0) {

			if (strcmp(p_value, "enable") == 0) {
				char *p_version = NULL;

				mproxy.igmp_version = IM_IGMPv3_MLDv2;

				p_version = strtok(NULL, " \t");

				if (p_version != NULL) {

					int  version    = 0;

					if (strcmp(p_version, "version") != 0) {

						IMP_LOG_ERROR("error token %s\n", p_version);
						goto out_error;
					}

					p_version = strtok(NULL, " \t");
					version = atoi(p_version);

					if (version < IM_IGMPv1 || version > IM_IGMPv3_MLDv2) {

						IMP_LOG_ERROR("error version %d, should be 1 2 or 3\n",
						              version);
						goto out_error;
					}

					mproxy.igmp_version = version;
				}
			} else if (strcmp(p_value, "disable") == 0) {
				mproxy.igmp_version = IM_DISABLE;
			} else {
				IMP_LOG_ERROR("error value %s, should be enable or disable\n",
				              p_value);
				goto out_error;
			}

		} else
#endif

#ifdef ENABLE_IMP_MLD
		if (strcmp(p_token, "mld") == 0) {

			if (strcmp(p_value, "enable") == 0) {

				char *p_version = NULL;

				mproxy.mld_version = IM_IGMPv3_MLDv2;

				p_version = strtok(NULL, " \t");

				if (p_version != NULL) {

					int  version    = 0;

					if (strcmp(p_version, "version") != 0) {

						IMP_LOG_ERROR("error token %s\n", p_version);
						goto out_error;
					}

					p_version = strtok(NULL, " \t");
					version = atoi(p_version);

					if (version < IM_IGMPv2_MLDv1 - 1 ||
					        version > IM_IGMPv3_MLDv2 - 1) {

						IMP_LOG_ERROR("error version %d, should be 1 or 2\n",
						              version - 1);
						goto out_error;
					}

					mproxy.mld_version = version + 1;
				}
			} else if (strcmp(p_value, "disable") == 0) {
				mproxy.mld_version = IM_DISABLE;
			} else {
				IMP_LOG_ERROR("error value %s, should be enable or disable\n", p_value);
				goto out_error;
			}

		} else
#endif
		if (strcmp(p_token, "upstream") == 0) {

			if (upinf[0]) {

				IMP_LOG_ERROR("only allow a upstream interface\n");
				goto out_error;
			}

			if (strlen(p_value) >= sizeof(upinf)) {
				IMP_LOG_ERROR("very long name for upstream iface: %s\n", p_value);
				goto out_error;
			}
			strcpy(upinf, p_value);
			IMP_LOG_DEBUG("upstream interface is %s\n", p_value);
		} else if (strcmp(p_token, "downstream") == 0) {

			if (strlen(p_value) >= sizeof(downinf[down_num])) {
				IMP_LOG_ERROR("very long name for downstream iface: %s\n", p_value);
				goto out_error;
			}
			strcpy(downinf[down_num], p_value);
			down_num++;
			IMP_LOG_DEBUG("downstream interface is %s\n", p_value);
		} else if (strcmp(p_token, "quickleave") == 0) {

			if (strcmp(p_value, "enable") == 0) {
				mproxy.quick_leave = 1;
			} else if (strcmp(p_value, "disable") == 0) {
				mproxy.quick_leave = 0;
			} else {

				IMP_LOG_ERROR("error value %s, should be enable or disable\n", p_value);
				goto out_error;
			}
		} else {

			IMP_LOG_ERROR("unknown token %s\n", p_token);
			goto out_error;
		}
	}

	if (upinf[0] == 0) {

		printf("improxy must be specified a upstream interface\n");
		goto out_error;
	}
#ifdef ENABLE_IMP_IGMP
	if (mproxy.igmp_version != IM_DISABLE) {

		imp_interface_create(upinf, AF_INET, INTERFACE_UPSTREAM);

		for (i = 0; i < down_num ; i ++) {
			imp_interface_create(downinf[i], AF_INET, INTERFACE_DOWNSTREAM);
		}

	}
#endif

#ifdef ENABLE_IMP_MLD
	if (mproxy.mld_version != IM_DISABLE) {

		imp_interface_create(upinf, AF_INET6, INTERFACE_UPSTREAM);

		for (i = 0; i < down_num; i ++) {

			imp_interface_create(downinf[i], AF_INET6, INTERFACE_DOWNSTREAM);
		}
	}
#endif

	status = STATUS_OK;

out_error:

	fclose(fd);
	return status;

}

int get_udp_socket(int family)
{
	if (family == AF_INET) {
		return mproxy.igmp_udp_socket;
	} else if (family == AF_INET6) {
		return mproxy.mld_udp_socket;
	} else {
		IMP_LOG_ERROR("unsoupprt family %d", family);
	}

	return 0;
}

int get_igmp_mld_socket(int family)
{
	if (family == AF_INET) {
		return mproxy.igmp_socket;
	} else if (family == AF_INET6) {
		return mproxy.mld_socket;
	} else {
		IMP_LOG_ERROR("unsoupprt family %d", family);
	}

	return 0;
}
int get_up_if_index(void)
{
	return mproxy.upif_index;
}
int get_im_version(int family)
{
	if (family == AF_INET) {
		return mproxy.igmp_version;
	} else if (family == AF_INET6) {
		return mproxy.mld_version;
	} else {
		IMP_LOG_ERROR("unsoupprt family %d", family);
	}

	return 0;
}

int get_group_leave_time()
{
	if (mproxy.quick_leave) {
		return 0;
	}

	return TIMER_LMQT;
}

#ifdef ENABLE_IMP_IGMP
STATUS init_mproxy4(mcast_proxy *p_mp)
{
	p_mp->igmp_socket = -1;
	p_mp->igmp_udp_socket = -1;

	if (p_mp->igmp_version == IM_DISABLE) {
		IMP_LOG_INFO("igmp: disabled: skip init\n");
		return STATUS_OK;
	}

	p_mp->igmp_socket = socket(AF_INET, SOCK_RAW, IPPROTO_IGMP);
	if (p_mp->igmp_socket == -1) {
		IMP_LOG_ERROR("igmp: can't create IGMP RAW socket: %s\n", strerror(errno));
		goto err_out;
	}
	IMP_LOG_DEBUG("igmp: IGMP RAW socket's fd: %d\n", p_mp->igmp_socket);

	int val = 1; /* set TTL = 1 */
	if (setsockopt(p_mp->igmp_socket, IPPROTO_IP, IP_MULTICAST_TTL, &val, sizeof(val))) {
		IMP_LOG_ERROR("igmp: set IP_MULTICAST_TTL failed: %s\n", strerror(errno));
		goto err_out;
	}

	val = 0; /* disable Multicast Loop */
	if (setsockopt(p_mp->igmp_socket, IPPROTO_IP, IP_MULTICAST_LOOP, &val, sizeof(val))) {
		IMP_LOG_ERROR("igmp: set IP_MULTICAST_LOOP failed: %s\n", strerror(errno));
		goto err_out;
	}

	val = 1; /* for info about incoming interface */
	if (setsockopt(p_mp->igmp_socket, IPPROTO_IP, IP_PKTINFO, &val, sizeof(val))) {
		IMP_LOG_ERROR("igmp: set IP_PKTINFO failed: %s\n", strerror(errno));
		goto err_out;
	}

	val = 0xC0; /* set DCSP mark CS6 for outgoing */
	if (setsockopt(p_mp->igmp_socket, IPPROTO_IP, IP_TOS, &val, sizeof(val))) {
		IMP_LOG_ERROR("igmp: set IP_TOS failed: %s\n", strerror(errno));
		goto err_out;
	}

	unsigned char ra_opt[4] = {148, 4, 0, 0}; /* RTR-ALERT option for outgoing */
	if (setsockopt(p_mp->igmp_socket, IPPROTO_IP, IP_OPTIONS, ra_opt, sizeof(ra_opt))) {
		IMP_LOG_ERROR("igmp: set IP_OPTIONS for RTR-ALERT failed: %s\n", strerror(errno));
		goto err_out;
	}

	if (k_start4_mproxy(p_mp->igmp_socket) != STATUS_OK) {
		IMP_LOG_ERROR("igmp: start kernel mutlicast routing failed\n");
		goto err_out;
	}

	p_mp->igmp_udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
	if (p_mp->igmp_udp_socket == -1) {
		IMP_LOG_ERROR("igmp: can't create udp socket: %s\n", strerror(errno));
		goto err_out;
	}
	IMP_LOG_DEBUG("igmp: UDP socket's fd: %d\n", p_mp->igmp_udp_socket);

	for (imp_interface *p_if = imp_interface_first(); p_if; p_if = LIST_NEXT(p_if, link)) {

		if (p_if->if_addr.ss.ss_family != AF_INET || p_if->type != INTERFACE_DOWNSTREAM) {
			continue;
		}

		pi_addr pia = {0};
		pia.ss.ss_family = AF_INET;

		pia.v4.sin_addr.s_addr = htonl(IGMP_ALL_ROUTERS);
		if (k_mcast_join(&pia, p_if->if_name) < 0) {
			IMP_LOG_ERROR("igmp: joining to ALL_ROUTERS on %s failed: %s\n",
			              p_if->if_name, strerror(errno));
			goto err_out;
		}

		if (p_mp->igmp_version < IM_IGMPv3_MLDv2) {
			continue;
		}
		/* On each interface over which this protocol for multicast router is being run,
		 * the router MUST enable reception of multicast address 224.0.0.22
		 * [RFC 3376 section 6]
		 */
		pia.v4.sin_addr.s_addr = htonl(IGMP_ALL_ROUTERS_V3);
		if (k_mcast_join(&pia, p_if->if_name) < 0) {
			IMP_LOG_ERROR("igmp: joining to ALL_ROUTERS_V3 on %s failed: %s\n",
			              p_if->if_name, strerror(errno));
			goto err_out;
		}
	}

	return STATUS_OK;

err_out:
	if (p_mp->igmp_socket != -1) {
		close(p_mp->igmp_socket);
	}

	if (p_mp->igmp_udp_socket != -1) {
		close(p_mp->igmp_udp_socket);
	}

	return STATUS_NOK;
}
#endif /* ENABLE_IMP_IGMP */

#ifdef ENABLE_IMP_MLD
STATUS init_mproxy6(mcast_proxy *p_mp)
{
	if (p_mp->mld_version == IM_DISABLE) {
		IMP_LOG_INFO("mld: disabled: skip init\n");
		return STATUS_OK;
	}

	p_mp->mld_socket = socket(AF_INET6, SOCK_RAW, IPPROTO_ICMPV6);
	if (p_mp->mld_socket == -1) {
		IMP_LOG_ERROR("mld: can't create ICMPv6 RAW socket: %s\n", strerror(errno));
		goto err_out;
	}
	IMP_LOG_DEBUG("mld: ICMPv6 RAW socket's fd: %d\n", p_mp->mld_socket);

	/* filter all non-MLD ICMP messages */
	struct icmp6_filter filt;
	ICMP6_FILTER_SETBLOCKALL(&filt);
	ICMP6_FILTER_SETPASS(MLD_LISTENER_REPORT, &filt);
	ICMP6_FILTER_SETPASS(MLD_LISTENER_REDUCTION, &filt);
	ICMP6_FILTER_SETPASS(MLD_V2_LISTENER_REPORT, &filt);

	if (setsockopt(p_mp->mld_socket, IPPROTO_ICMPV6, ICMP6_FILTER, &filt, sizeof(filt))) {
		IMP_LOG_ERROR("mld: set ICMP6_FILTER failed: %s\n", strerror(errno));
		goto err_out;
	}

	int val = 1; /* set Hop Limit = 1 */
	if (setsockopt(p_mp->mld_socket, IPPROTO_IPV6, IPV6_MULTICAST_HOPS, &val, sizeof(val))) {
		IMP_LOG_ERROR("mld: set IPV6_MULTICAST_HOPS failed: %s\n", strerror(errno));
		goto err_out;
	}

	val = 0; /* disable Multicast Loop */
	if (setsockopt(p_mp->mld_socket, IPPROTO_IPV6, IPV6_MULTICAST_LOOP, &val, sizeof(val))) {
		IMP_LOG_ERROR("mld: set IPV6_MULTICAST_LOOP failed: %s\n", strerror(errno));
		goto err_out;
	}

	val = 1; /* for extracting info about RTR-ALERT */
	if (setsockopt(p_mp->mld_socket, IPPROTO_IPV6, IPV6_RECVHOPOPTS, &val, sizeof(val))) {
		IMP_LOG_ERROR("mld: set IPV6_RECVHOPOPTS failed: %s\n", strerror(errno));
		goto err_out;
	}

	val = 1; /* for extracting info about Hop Limit */
	if (setsockopt(p_mp->mld_socket, IPPROTO_IPV6, IPV6_RECVHOPLIMIT, &val, sizeof(val))) {
		IMP_LOG_ERROR("mld: set IPV6_RECVHOPLIMIT failed: %s\n", strerror(errno));
		goto err_out;
	}

	/* set RTR-ALERT option */
	static struct {
		struct ip6_hbh hdr;
		struct ip6_opt_router rt;
		unsigned char padding[2];
	} hopts = {
		.hdr = {0, 0},
		.rt = {IP6OPT_ROUTER_ALERT, 2, {0, IP6_ALERT_MLD}},
		.padding = {0x1, 0} /* PadN option, see RFC 2460, 4.2 */
	};

	if (setsockopt(p_mp->mld_socket, IPPROTO_IPV6, IPV6_HOPOPTS, &hopts, sizeof(hopts))) {
		IMP_LOG_ERROR("mld: set IPV6_HOPOPTS failed: %s\n", strerror(errno));
		goto err_out;
	}

	if (k_start6_mproxy(p_mp->mld_socket) < 0) {
		IMP_LOG_ERROR("mld: start kernel multicast routing failed\n");
		goto err_out;
	}

	p_mp->mld_udp_socket = socket(AF_INET6, SOCK_DGRAM, 0);
	if (p_mp->mld_udp_socket == -1) {
		IMP_LOG_ERROR("mld: can't create udp socket: %s\n", strerror(errno));
		goto err_out;
	}
	IMP_LOG_DEBUG("mld: UDP socket's fd: %d\n", p_mp->mld_udp_socket);

	for (imp_interface *p_if = imp_interface_first(); p_if; p_if = LIST_NEXT(p_if, link)) {

		if (p_if->if_addr.ss.ss_family != AF_INET6 || p_if->type != INTERFACE_DOWNSTREAM) {
			continue;
		}

		pi_addr pia = {0};
		pia.ss.ss_family = AF_INET6;

		memcpy(&pia.v6.sin6_addr.s6_addr, MLD_ALL_ROUTERS, sizeof(MLD_ALL_ROUTERS));
		if (k_mcast_join(&pia, p_if->if_name) < 0) {
			IMP_LOG_DEBUG("mld: joining to ALL_V6_ROUTERS on %s failed: %s\n",
			              p_if->if_name, strerror(errno));
		}

		if (p_mp->mld_version < IM_IGMPv3_MLDv2) {
			continue;
		}

		memcpy(&pia.v6.sin6_addr.s6_addr, MLD_ALL_ROUTERS_V3, sizeof(MLD_ALL_ROUTERS_V3));
		if (k_mcast_join(&pia, p_if->if_name) < 0) {
			IMP_LOG_DEBUG("mld: joining to MLDv2 REPORTS on %s failed: %s\n",
			              p_if->if_name, strerror(errno));
		}
	}
	return STATUS_OK;

err_out:
	if (p_mp->mld_socket != -1) {
		close(p_mp->mld_socket);
	}

	if (p_mp->mld_udp_socket != -1) {
		close(p_mp->mld_udp_socket);
	}

	return STATUS_NOK;
}
#endif /* ENABLE_IMP_MLD */

void init_timer(void)
{
	imp_interface *p_if;

	for (p_if = imp_interface_first(); p_if; p_if = LIST_NEXT(p_if, link)) {
		if (p_if->type == INTERFACE_UPSTREAM) {
			continue;
		}

		p_if->startup = DEFAULT_RV;
		p_if->gq_timer = imp_add_timer(general_queries_timer_handler, p_if);
		/*send generial query fast*/
		imp_set_timer(2, p_if->gq_timer);
	}
}
static void sig_term_handler()
{
	if (pid_file[0] != 0) {
		unlink(pid_file);
	}
	exit(EXIT_SUCCESS);
}
static void sig_usr1_handler()
{
	imp_interface *p_if;

	for (p_if = imp_interface_first(); p_if; p_if = LIST_NEXT(p_if, link)) {
		if (p_if->type == INTERFACE_UPSTREAM) {
			continue;
		}

		imp_group_print(p_if);
	}

	imp_membership_db_print_all();
}
static void show_usage()
{
	printf("Usage: improxy -c config file \n"
	       "\t-d log level 1,2,3,4,5\n"
	       "\t-p pid file\n"
	       "\t-v show version\n"
	       "\t-h this help\n"
	       "Version: %s\n", IMP_VERSION);
	exit(EXIT_FAILURE);
}
int main(int argc, char *argv[])
{
	int opt = 10, pid = 0;
	char    config[1024] = {0};
	int log_level = 0;
	FILE *pidfp;

	memset(&mproxy, 0, sizeof(mcast_proxy));

	mproxy.print_level = 0; //disable log to stdout
	mproxy.syslog_level = LOG_PRI_ERROR;

	while ((opt = getopt(argc, argv, "c:d:vp:h")) > 0) {
		switch (opt) {
		case 'c':
			IMP_LOG_DEBUG("config file is %s\n", optarg);
			strcpy(config, optarg);
			break;

		case 'p':
			IMP_LOG_DEBUG("pid file is %s\n", optarg);
			strcpy(pid_file, optarg);
			break;

		case 'd':
			/*to do log*/
			log_level = atoi(optarg);

			if (log_level < 0) {
				IMP_LOG_DEBUG("log level must be greater than 0\n");
				exit(EXIT_FAILURE);
			}

			if (log_level > LOG_PRI_LOWEST) {
				log_level = LOG_PRI_DEBUG;
			}

			mproxy.syslog_level = log_level;
			IMP_LOG_DEBUG("logLevel = %d\n", log_level);
			break;

		case 'v':
			printf("version: %s\n", IMP_VERSION);
			exit(EXIT_SUCCESS);

		default:
			show_usage();
		}

	}

	if (config[0] == 0) {

		show_usage();
	}

	if (geteuid()) {
		IMP_LOG_FATAL("you must be a root!\n");
		exit(EXIT_FAILURE);
	}

	/* dump current PID */
	pid = getpid();

	if ((pidfp = fopen(pid_file, "w")) != NULL) {
		fprintf(pidfp, "%d\n", pid);
		fclose(pidfp);
	}

	signal(SIGTERM, sig_term_handler);
	signal(SIGINT, sig_term_handler);
	signal(SIGUSR1, sig_usr1_handler);

	imp_interface_init();
	imp_init_timer();
	imp_membership_db_init();


	if (load_config(config) == STATUS_NOK ||
	        init_interface(&mproxy) == STATUS_NOK
#ifdef ENABLE_IMP_IGMP
	        || init_mproxy4(&mproxy) == STATUS_NOK
#endif
#ifdef ENABLE_IMP_MLD
	        || init_mproxy6(&mproxy) == STATUS_NOK
#endif
	   ) {

		IMP_LOG_ERROR("exiting.........\n");
		exit(EXIT_FAILURE);
	}

	add_all_vif();
	init_timer();


	while (1) {
		struct timeval *tm;
		fd_set  fdset;
		int max = 0;
		int resval = 0;
		FD_ZERO(&fdset);

#ifdef ENABLE_IMP_IGMP
		if (mproxy.igmp_socket > 0)
			FD_SET(mproxy.igmp_socket, &fdset);
#endif /* ENABLE_IMP_IGMP */

#ifdef ENABLE_IMP_MLD
		if (mproxy.mld_socket > 0)
			FD_SET(mproxy.mld_socket, &fdset);
#endif /* ENABLE_IMP_MLD */

		max = mproxy.igmp_socket > mproxy.mld_socket ?
		      mproxy.igmp_socket : mproxy.mld_socket;

		tm = imp_check_timer();

		resval = select(max + 1, &fdset, NULL, NULL, tm);

		if (resval == -1) {
			IMP_LOG_ERROR("select error: %s\n", strerror(errno));
		} else if (resval) {
			IMP_LOG_DEBUG("Data arrive\n");
		} else {
			IMP_LOG_DEBUG("timeout\n");
		}

#ifdef ENABLE_IMP_IGMP
		if (mproxy.igmp_socket > 0 && FD_ISSET(mproxy.igmp_socket, &fdset))
			mcast_recv_igmp();
#endif /* ENABLE_IMP_IGMP */

#ifdef ENABLE_IMP_MLD
		if (mproxy.mld_socket > 0 && FD_ISSET(mproxy.mld_socket, &fdset))
			mcast_recv_mld();
#endif /* ENABLE_IMP_MLD */
	}

	return 0;
}
