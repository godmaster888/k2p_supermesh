/*-
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Copyright (c) 1991, 1993
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 *	@(#)queue.h	8.5 (Berkeley) 8/20/94
 * $FreeBSD$
 */

#ifndef    IMP_BSD_LIST_H
#define    IMP_BSD_LIST_H

/* A list is headed by a structure defined by the LIST_HEAD macro. This
 * structure contains a single pointer to the first element on the list.
 * The elements are doubly linked so that an arbitrary element can be
 * removed without traversing the list. New elements can be added to the
 * list after an existing element, before an existing element, or at the
 * head of the list. A LIST_HEAD structure is declared as follows:
 *
 *         LIST_HEAD(HEADNAME, TYPE) head;
 *
 * where HEADNAME is the name of the structure to be defined, and TYPE is
 * the type of the elements to be linked into the list. A pointer to the
 * head of the list can later be declared as:
 *
 *         struct HEADNAME *headp;
 *
 * (The names head and headp are user selectable.)
 */

/*
 * List declarations.
 */
#define	LIST_HEAD(name, type)											\
struct name {															\
	struct type *lh_first;	/* first element */							\
}

/* Evaluates to an initializer for the list head. */
#define	LIST_HEAD_INITIALIZER(head)										\
	{ NULL }

/* Declares a structure that connects the elements in the list. */
#define	LIST_ENTRY(type)												\
struct {																\
	struct type *le_next;	/* next element */							\
	struct type **le_prev;	/* address of previous next element */		\
}

/*
 * List functions.
 */

/* Evaluates to true if there are no elements in the list */
#define	LIST_EMPTY(head)	((head)->lh_first == NULL)

/* Returns the first element in the list or NULL if the list is empty. */
#define	LIST_FIRST(head)	((head)->lh_first)

/* Traverses the list referenced by head in the forward direction,
 * assigning each element in turn to var.
 */
#define	LIST_FOREACH(var, head, field)									\
	for ((var) = LIST_FIRST((head));									\
	    (var);															\
	    (var) = LIST_NEXT((var), field))

/* Behaves identically to LIST_FOREACH when var is NULL,
 * else it treats var as a previously found LIST element and begins
 * the loop at var instead of the first element in the LIST referenced by head.
 */
#define	LIST_FOREACH_FROM(var, head, field)								\
	for ((var) = ((var) ? (var) : LIST_FIRST((head)));					\
	    (var);															\
	    (var) = LIST_NEXT((var), field))

/* Traverses the list referenced by head in the
 * forward direction, assigning each element in turn to var. However,
 * unlike LIST_FOREACH() here it is permitted to both remove var as well as
 * free it from within the loop safely without interfering with the traversal.
 */
#define	LIST_FOREACH_SAFE(var, head, field, tvar)						\
	for ((var) = LIST_FIRST((head));									\
	    (var) && ((tvar) = LIST_NEXT((var), field), 1);					\
	    (var) = (tvar))

/* The macro LIST_FOREACH_FROM_SAFE behaves identically to LIST_FOREACH_SAFE
 * when var is NULL, else it treats var as a previously found	LIST element
 * and begins	the loop at var	instead	of the first element in	the LIST
 * referenced by head.
 */
#define	LIST_FOREACH_FROM_SAFE(var, head, field, tvar)					\
	for ((var) = ((var) ? (var) : LIST_FIRST((head)));					\
	    (var) && ((tvar) = LIST_NEXT((var), field), 1);					\
	    (var) = (tvar))

/* The macro LIST_INIT initializes the list referenced by head. */
#define	LIST_INIT(head) do {											\
	LIST_FIRST((head)) = NULL;											\
} while (0)

/* The macro LIST_INSERT_AFTER inserts the new element elm
 * after the element listelm.
 */
#define	LIST_INSERT_AFTER(listelm, elm, field) do {						\
	if ((LIST_NEXT((elm), field) = LIST_NEXT((listelm), field)) != NULL)\
		LIST_NEXT((listelm), field)->field.le_prev =					\
		    &LIST_NEXT((elm), field);									\
	LIST_NEXT((listelm), field) = (elm);								\
	(elm)->field.le_prev = &LIST_NEXT((listelm), field);				\
} while (0)

/* The macro LIST_INSERT_BEFORE inserts the new element elm
 * before the element listelm.
 */
#define	LIST_INSERT_BEFORE(listelm, elm, field) do {					\
	(elm)->field.le_prev = (listelm)->field.le_prev;					\
	LIST_NEXT((elm), field) = (listelm);								\
	*(listelm)->field.le_prev = (elm);									\
	(listelm)->field.le_prev = &LIST_NEXT((elm), field);				\
} while (0)

/*  The macro LIST_INSERT_HEAD inserts the new element elm
 *  at the head of the list.
 */
#define	LIST_INSERT_HEAD(head, elm, field) do {							\
	if ((LIST_NEXT((elm), field) = LIST_FIRST((head))) != NULL)			\
		LIST_FIRST((head))->field.le_prev = &LIST_NEXT((elm), field);	\
	LIST_FIRST((head)) = (elm);											\
	(elm)->field.le_prev = &LIST_FIRST((head));							\
} while (0)

/* The macro LIST_NEXT returns the next element in the list,
 * or NULL if this is the last.
 */
#define	LIST_NEXT(elm, field)	((elm)->field.le_next)

/* The macro LIST_REMOVE removes the element elm from the list. */
#define	LIST_REMOVE(elm, field) do {									\
	if (LIST_NEXT((elm), field) != NULL)								\
		LIST_NEXT((elm), field)->field.le_prev =						\
		    (elm)->field.le_prev;										\
	*(elm)->field.le_prev = LIST_NEXT((elm), field);					\
} while (0)

/* The macro LIST_SWAP swaps the contents of head1 and head2. */
#define LIST_SWAP(head1, head2, type, field) do {						\
	struct type *swap_tmp = LIST_FIRST(head1);							\
	LIST_FIRST((head1)) = LIST_FIRST((head2));							\
	LIST_FIRST((head2)) = swap_tmp;										\
	if ((swap_tmp = LIST_FIRST((head1))) != NULL)						\
		swap_tmp->field.le_prev = &LIST_FIRST((head1));					\
	if ((swap_tmp = LIST_FIRST((head2))) != NULL)						\
		swap_tmp->field.le_prev = &LIST_FIRST((head2));					\
} while (0)

#endif /* IMP_BSD_LIST_H */
