#include "plugin.h"

#define DNS_MASTER_UPDATE_IP_REQUEST	\
	"GET %s?"							\
	"hostname=%s&"						\
	"myip=%s "							\
	"HTTP/1.0\r\n"						\
	"Host: %s\r\n"						\
	"Authorization: Basic %s\r\n"		\
	"User-Agent: %s\r\n\r\n"

static int request  (ddns_t       *ctx,   ddns_info_t *info, ddns_alias_t *alias);
static int response (http_trans_t *trans, ddns_info_t *info, ddns_alias_t *alias);

static ddns_system_t plugin = {
	.name         = "default@dns-master.ru",

	.request      = (req_fn_t)request,
	.response     = (rsp_fn_t)response,

	.checkip_name = "api.nic.ru",
	.checkip_url  = "/dyndns/checkip",

	.server_name  = "api.nic.ru",
	.server_url   = "/dyndns/update"
};

static int request(ddns_t *ctx, ddns_info_t *info, ddns_alias_t *alias)
{
	return snprintf(ctx->request_buf, ctx->request_buflen,
			DNS_MASTER_UPDATE_IP_REQUEST,
			info->server_url,
			alias->name,
			alias->address,
			info->server_name.name,
			info->creds.encoded_password,
			user_agent);
}

static int response(http_trans_t *trans, ddns_info_t *info, ddns_alias_t *alias)
{
	char *body = trans->rsp_body;

	DO(http_status_valid(trans->status));

	if (strstr(body, "good"))
		return 0;

	if (strstr(body, "dnserr") || strstr(body, "nohost"))
		return RC_DDNS_RSP_RETRY_LATER;

	return RC_DDNS_RSP_NOTOK;
}

PLUGIN_INIT(plugin_init)
{
	plugin_register(&plugin);
}

PLUGIN_EXIT(plugin_exit)
{
	plugin_unregister(&plugin);
}
