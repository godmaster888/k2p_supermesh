#!/bin/bash

# Recompiles the database using static keys and predefined username
#
# Static keys are needed because of multiple builds made on different machines.
# The main problems here are
# 1) private key is stored in temporary builder storage
# 2) every build will produce different certificate
#
# By default Makefile use file ~/.wireless-regdb-$USER.key.priv.pem outside of
# this repo, making builds on different machines impossible.
#
# As a solution, we create a single static keyset and use it in any build.
# So no more weird errors anymore because of private key/certificate mismatch:
#
# 4160407296:error:0B080074:x509 certificate routines:X509_check_private_key:key values mismatch:../crypto/x509/x509_cmp.c:295:
# 4160407296:error:2108907F:PKCS7 routines:PKCS7_sign_add_signer:private key does not match certificate:../crypto/pkcs7/pk7_smime.c:117:
#

# Clean previous build
make maintainer-clean

# Substitute the username, keys and certificate
make \
	REGDB_AUTHOR=builder \
	REGDB_PRIVKEY=builder.key.priv.pem \
	REGDB_PUBKEY=builder.key.pub.pem \
	REGDB_PUBCERT=builder.x509.pem
